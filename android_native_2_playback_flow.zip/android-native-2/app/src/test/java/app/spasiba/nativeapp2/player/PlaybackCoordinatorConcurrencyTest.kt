package app.spasiba.nativeapp2.player

import app.spasiba.nativeapp2.data.api.StreamingResult
import app.spasiba.nativeapp2.data.cache.QueueSnapshot
import app.spasiba.nativeapp2.data.model.Song
import app.spasiba.nativeapp2.data.repository.LyricLine
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.IOException

/**
 * Headless fake PlayerEngine for deterministic unit testing.
 */
class FakePlayerEngine : PlayerEngine {
    override var isPlaying: Boolean = false
    override var currentPosition: Long = 0L
    override var duration: Long = 200000L
    override var playbackState: Int = PlayerEngine.STATE_IDLE
    var lastMediaUri: String? = null
    var prepareCalled: Boolean = false
    private var engineListener: PlayerEngine.Listener? = null

    override fun play() {
        isPlaying = true
        playbackState = PlayerEngine.STATE_READY
        engineListener?.onIsPlayingChanged(true)
        engineListener?.onPlaybackStateChanged(PlayerEngine.STATE_READY)
    }

    override fun pause() {
        isPlaying = false
        engineListener?.onIsPlayingChanged(false)
    }

    override fun stop() {
        isPlaying = false
        playbackState = PlayerEngine.STATE_IDLE
        engineListener?.onIsPlayingChanged(false)
        engineListener?.onPlaybackStateChanged(PlayerEngine.STATE_IDLE)
    }

    override fun seekTo(positionMs: Long) {
        currentPosition = positionMs
    }

    override fun setMediaSource(uri: String, song: Song?, headers: Map<String, String>?, isFile: Boolean) {
        lastMediaUri = uri
    }

    override fun setMergingMediaSource(videoUri: String, audioUri: String, song: Song?, headers: Map<String, String>?) {
        lastMediaUri = videoUri
    }

    override fun prepare() {
        prepareCalled = true
        playbackState = PlayerEngine.STATE_READY
        engineListener?.onPlaybackStateChanged(PlayerEngine.STATE_READY)
    }

    override fun clearMediaItems() {
        lastMediaUri = null
    }

    override fun setPlaybackSpeed(speed: Float) {}

    override fun setListener(listener: PlayerEngine.Listener) {
        this.engineListener = listener
    }

    fun triggerEnded() {
        isPlaying = false
        playbackState = PlayerEngine.STATE_ENDED
        engineListener?.onIsPlayingChanged(false)
        engineListener?.onPlaybackStateChanged(PlayerEngine.STATE_ENDED)
    }

    fun triggerError(errorCode: Int, message: String?) {
        isPlaying = false
        engineListener?.onPlayerError(errorCode, message)
    }
}

/**
 * Headless fake StreamResolver with controllable deferred responses.
 */
class FakeStreamResolver : StreamResolver {
    val streamResults = mutableMapOf<String, StreamingResult>()
    var manualDeferred: CompletableDeferred<StreamingResult?>? = null
    var shouldThrowException: Boolean = false
    var lyricsShouldThrowException: Boolean = false

    override suspend fun resolveAudioStream(songId: String, title: String, author: String): StreamingResult? {
        if (shouldThrowException) throw IOException("Simulated network timeout/error")
        manualDeferred?.let { return it.await() }
        return streamResults[songId] ?: StreamingResult(
            url = "https://stream.spasiba.app/$songId.m4a",
            audioUrl = null,
            headers = emptyMap()
        )
    }

    override suspend fun resolveVideoStream(videoId: String, quality: String): StreamingResult? {
        return StreamingResult(
            url = "https://stream.spasiba.app/video_$videoId.mp4",
            audioUrl = "https://stream.spasiba.app/audio_$videoId.m4a",
            headers = emptyMap()
        )
    }

    override suspend fun fetchUnifiedLyrics(songId: String, title: String, author: String, durationSec: Int): List<LyricLine> {
        if (lyricsShouldThrowException) throw IOException("Simulated lyrics timeout/500")
        return listOf(LyricLine(0L, "Sample Lyric Line"))
    }

    override suspend fun generateRadioQueue(seedSong: Song): List<Song> {
        return (1..5).map {
            Song(
                id = "radio_$it",
                title = "Radio Title $it",
                author = seedSong.author,
                thumbnail = "",
                durationSeconds = 180,
                views = 500L
            )
        }
    }

    override suspend fun searchSongs(query: String): List<Song> {
        return (1..3).map {
            Song(
                id = "search_$it",
                title = "Search Title $it",
                author = "Artist",
                thumbnail = "",
                durationSeconds = 180,
                views = 500L
            )
        }
    }
}

/**
 * Headless fake QueueStore for snapshot persistence verification.
 */
class FakeQueueStore : QueueStore {
    var savedSongs: List<Song> = emptyList()
    var savedIndex: Int = -1
    var savedPositionMs: Long = 0L

    override suspend fun saveSnapshot(songs: List<Song>, currentIndex: Int, positionMs: Long) {
        savedSongs = songs
        savedIndex = currentIndex
        savedPositionMs = positionMs
    }

    override suspend fun restoreSnapshot(): QueueSnapshot? {
        return if (savedSongs.isNotEmpty()) QueueSnapshot(savedSongs, savedIndex, savedPositionMs) else null
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class PlaybackCoordinatorConcurrencyTest {

    private val testDispatcher = StandardTestDispatcher()
    private lateinit var fakeEngine: FakePlayerEngine
    private lateinit var fakeResolver: FakeStreamResolver
    private lateinit var fakeQueueStore: FakeQueueStore
    private lateinit var coordinator: PlaybackCoordinator

    private fun createDummySong(id: String, title: String = "Title $id"): Song {
        return Song(
            id = id,
            title = title,
            author = "Artist $id",
            thumbnail = "https://example.com/thumb_$id.jpg",
            durationSeconds = 200,
            views = 1000L
        )
    }

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        fakeEngine = FakePlayerEngine()
        fakeResolver = FakeStreamResolver()
        fakeQueueStore = FakeQueueStore()
        coordinator = PlaybackCoordinator(
            engine = fakeEngine,
            resolver = fakeResolver,
            queueStore = fakeQueueStore,
            scope = CoroutineScope(SupervisorJob() + testDispatcher),
            ioDispatcher = testDispatcher,
            mainDispatcher = testDispatcher
        ).apply {
            progressTickerEnabled = false
            queueDebounceMs = 0L
        }
    }

    @After
    fun tearDown() {
        coordinator.clearQueue()
        Dispatchers.resetMain()
    }

    @Test
    fun testA_playThenPauseWhileResolving_staysPausedWhenResolved() = runTest(testDispatcher) {
        val songA = createDummySong("A")
        val deferred = CompletableDeferred<StreamingResult?>()
        fakeResolver.manualDeferred = deferred

        // 1. User commands play(A) -> resolver begins
        coordinator.playStandaloneItem(songA)
        advanceUntilIdle()
        assertEquals(PlaybackStatus.RESOLVING, coordinator.playbackStatus.value)

        // 2. User commands pause() while resolver in-flight
        coordinator.pause()
        assertEquals(DesiredPlaybackState.PAUSED, coordinator.desiredPlaybackState)

        // 3. Resolver completes asynchronously
        deferred.complete(StreamingResult("https://cdn.example.com/A.m4a", null, emptyMap()))
        advanceUntilIdle()

        // 4. Assert player engine prepared but DID NOT start playing!
        assertEquals(PlaybackStatus.PAUSED, coordinator.playbackStatus.value)
        assertFalse(fakeEngine.isPlaying)
        assertFalse(coordinator.isPlaying.value)
        assertEquals(songA.id, coordinator.currentSong.value?.id)
    }

    @Test
    fun testB_playThenClearQueue_invalidatesInFlightPlayback() = runTest(testDispatcher) {
        val songA = createDummySong("A")
        val deferred = CompletableDeferred<StreamingResult?>()
        fakeResolver.manualDeferred = deferred

        // 1. Play song A
        coordinator.playStandaloneItem(songA)
        advanceUntilIdle()

        // 2. Clear queue immediately
        coordinator.clearQueue()
        advanceUntilIdle()
        assertEquals(PlaybackStatus.IDLE, coordinator.playbackStatus.value)
        assertNull(coordinator.currentSong.value)
        assertTrue(coordinator.queue.value.isEmpty())

        // 3. Late network returns for song A
        deferred.complete(StreamingResult("https://cdn.example.com/A.m4a", null, emptyMap()))
        advanceUntilIdle()

        // 4. Assert late result is completely discarded, queue remains empty!
        assertEquals(PlaybackStatus.IDLE, coordinator.playbackStatus.value)
        assertNull(coordinator.currentSong.value)
        assertTrue(coordinator.queue.value.isEmpty())
        assertFalse(fakeEngine.isPlaying)
    }

    @Test
    fun testC_playSongFromSearch_establishesValidQueueContext() = runTest(testDispatcher) {
        val searchSong = createDummySong("Search123")
        coordinator.playSong(searchSong)
        advanceUntilIdle()

        assertEquals(searchSong.id, coordinator.currentSong.value?.id)
        assertEquals(0, coordinator.currentIndex.value)
        assertTrue(coordinator.queue.value.isNotEmpty())
        assertEquals(searchSong.id, coordinator.queue.value[0].id)
    }

    @Test
    fun testD_playA_thenPlayB_beforeAResolves_commitsBOnly() = runTest(testDispatcher) {
        val songA = createDummySong("A")
        val songB = createDummySong("B")

        val deferredA = CompletableDeferred<StreamingResult?>()
        fakeResolver.manualDeferred = deferredA

        // 1. Start A
        coordinator.playStandaloneItem(songA)
        advanceUntilIdle()

        // 2. Switch to B with immediate resolution
        fakeResolver.manualDeferred = null
        coordinator.playStandaloneItem(songB)
        advanceUntilIdle()

        assertEquals(songB.id, coordinator.currentSong.value?.id)

        // 3. Late A completes
        deferredA.complete(StreamingResult("https://cdn.example.com/A.m4a", null, emptyMap()))
        advanceUntilIdle()

        // 4. Assert B is still playing, A was ignored
        assertEquals(songB.id, coordinator.currentSong.value?.id)
        assertEquals(PlaybackStatus.PLAYING, coordinator.playbackStatus.value)
    }

    @Test
    fun testE_endOfTrackWithSimultaneousUserSelection_selectsUserTarget() = runTest(testDispatcher) {
        val songA = createDummySong("A")
        val songB = createDummySong("B")
        coordinator.playQueue(listOf(songA, songB), 0)
        advanceUntilIdle()

        assertEquals("A", coordinator.currentSong.value?.id)

        // User rapidly taps song B at the same moment track ends
        coordinator.playQueueItem(songB.id)
        fakeEngine.triggerEnded()
        advanceUntilIdle()

        assertEquals("B", coordinator.currentSong.value?.id)
        assertEquals(1, coordinator.currentIndex.value)
    }

    @Test
    fun testF_shuffleOn_addRemoveMove_shuffleOff_preservesCanonical() = runTest(testDispatcher) {
        val songs = listOf(
            createDummySong("1"),
            createDummySong("2"),
            createDummySong("3"),
            createDummySong("4")
        )
        coordinator.setQueue(songs, "2")
        advanceUntilIdle()

        // 1. Shuffle ON
        coordinator.toggleShuffle()
        advanceUntilIdle()
        assertTrue(coordinator.isShuffleEnabled.value)
        assertEquals("2", coordinator.currentSong.value?.id)

        // 2. Add song "5"
        val song5 = createDummySong("5")
        coordinator.addToQueue(song5)
        advanceUntilIdle()

        // 3. Shuffle OFF -> Canonical restored with song "5" preserved!
        coordinator.toggleShuffle()
        advanceUntilIdle()
        assertFalse(coordinator.isShuffleEnabled.value)
        val canonical = coordinator.queue.value
        val userTrackIds = canonical.map { it.id }.filter { it in listOf("1", "2", "3", "4", "5") }
        assertEquals(listOf("1", "2", "3", "4", "5"), userTrackIds)
        assertEquals(1, coordinator.currentIndex.value)
        assertEquals("2", coordinator.currentSong.value?.id)
    }

    @Test
    fun testG_repeatOne_replaysWithCleanGeneration() = runTest(testDispatcher) {
        val songA = createDummySong("A")
        coordinator.playStandaloneItem(songA)
        advanceUntilIdle()

        coordinator.toggleRepeat() // ALL
        advanceUntilIdle()
        coordinator.toggleRepeat() // ONE
        advanceUntilIdle()
        assertEquals(RepeatState.ONE, coordinator.repeatState.value)

        val initialGen = coordinator.playbackGeneration
        fakeEngine.triggerEnded()
        advanceUntilIdle()

        // Assert replayed under new generation
        assertTrue(coordinator.playbackGeneration > initialGen)
        assertEquals("A", coordinator.currentSong.value?.id)
        assertEquals(PlaybackStatus.PLAYING, coordinator.playbackStatus.value)
    }

    @Test
    fun testH_recoveryExceptionAlwaysTerminatesWithoutHanging() = runTest(testDispatcher) {
        val songA = createDummySong("A")
        coordinator.playStandaloneItem(songA)
        advanceUntilIdle()

        // Simulate network failure on recovery
        fakeResolver.shouldThrowException = true
        fakeEngine.triggerError(500, "Network timeout")
        advanceUntilIdle()

        // Assert recovery terminated into FAILED (not stuck in RECOVERING)
        assertNotEquals(PlaybackStatus.RECOVERING, coordinator.playbackStatus.value)
        assertEquals(PlaybackStatus.FAILED, coordinator.playbackStatus.value)
    }

    @Test
    fun testI_setQueueEmpty_clearsQueueAndPersistsEmptyState() = runTest(testDispatcher) {
        val songs = listOf(createDummySong("1"), createDummySong("2"))
        coordinator.playQueue(songs, 0)
        advanceUntilIdle()

        assertTrue(coordinator.queue.value.isNotEmpty())

        // Set empty list
        coordinator.setQueue(emptyList(), null)
        advanceUntilIdle()

        assertTrue(coordinator.queue.value.isEmpty())
        assertEquals(-1, coordinator.currentIndex.value)
        assertNull(coordinator.currentSong.value)
        assertEquals(emptyList<Song>(), fakeQueueStore.savedSongs)
    }

    @Test
    fun testJ_monkey10000RandomOperations_preservesInvariantStrictly() = runTest(testDispatcher) {
        val initialSongs = (1..5).map { createDummySong("init_$it") }
        coordinator.playQueue(initialSongs, 0)
        advanceUntilIdle()

        for (i in 1..10000) {
            when (i % 6) {
                0 -> coordinator.addToQueue(createDummySong("rand_$i"))
                1 -> {
                    val q = coordinator.queue.value
                    if (q.size > 1) coordinator.removeFromQueue(0)
                }
                2 -> coordinator.playNext()
                3 -> coordinator.playPrevious()
                4 -> coordinator.toggleShuffle()
                5 -> coordinator.toggleRepeat()
            }
            advanceUntilIdle()

            // Strict Invariant Check
            val q = coordinator.queue.value
            val idx = coordinator.currentIndex.value
            val song = coordinator.currentSong.value

            if (q.isEmpty()) {
                assertEquals(-1, idx)
                assertNull(song)
            } else {
                assertTrue(idx in q.indices)
                assertEquals(q[idx].id, song?.id)
            }
        }
    }

    @Test
    fun testK_lyricsResolverException_alwaysResetsLoadingToFalse() = runTest(testDispatcher) {
        val songA = createDummySong("A")
        fakeResolver.lyricsShouldThrowException = true

        coordinator.playStandaloneItem(songA)
        advanceUntilIdle()

        // Assert lyrics loading flag is strictly FALSE despite 500 error
        assertFalse(coordinator.isLyricsLoading.value)
        assertTrue(coordinator.syncedLyrics.value.isEmpty())
    }

    @Test
    fun testL_playNextWhileShuffled_insertsAfterCurrentWithoutCorruptingCanonical() = runTest(testDispatcher) {
        val songs = listOf(
            createDummySong("1"),
            createDummySong("2"),
            createDummySong("3"),
            createDummySong("4")
        )
        coordinator.setQueue(songs, "1")
        advanceUntilIdle()

        coordinator.toggleShuffle()
        advanceUntilIdle()
        assertTrue(coordinator.isShuffleEnabled.value)

        val nextSong = createDummySong("NextBonus")
        coordinator.playNextInQueue(nextSong)
        advanceUntilIdle()

        // In active queue: index 1 is immediately NextBonus
        val activeQueue = coordinator.queue.value
        assertEquals("NextBonus", activeQueue[1].id)

        // Unshuffle: Canonical order baseline was UNCHANGED (1, 2, 3, 4)
        coordinator.toggleShuffle()
        advanceUntilIdle()
        assertFalse(coordinator.isShuffleEnabled.value)
        val canonicalIds = coordinator.queue.value.map { it.id }.filter { it in listOf("1", "2", "3", "4") }
        assertEquals(listOf("1", "2", "3", "4"), canonicalIds)
        assertEquals("1", coordinator.currentSong.value?.id)
    }

    @Test
    fun testM_recoveryCancellation_cancelsOngoingRecoveryWhenUserSwitchesTrack() = runTest(testDispatcher) {
        val songA = createDummySong("A")
        val songB = createDummySong("B")

        coordinator.playStandaloneItem(songA)
        advanceUntilIdle()

        // Simulate error on A
        fakeResolver.shouldThrowException = true
        fakeEngine.triggerError(500, "Network timeout")
        assertEquals(PlaybackStatus.RECOVERING, coordinator.playbackStatus.value)

        // User immediately commands B before recovery completes
        fakeResolver.shouldThrowException = false
        coordinator.playStandaloneItem(songB)
        advanceUntilIdle()

        // Assert B is playing, recovery on A was cancelled
        assertEquals(songB.id, coordinator.currentSong.value?.id)
        assertEquals(PlaybackStatus.PLAYING, coordinator.playbackStatus.value)
    }

    @Test
    fun testN_smartQueueStaleGeneration_resetsWarmedMarkerAndPermitsRetry() = runTest(testDispatcher) {
        val songA = createDummySong("A")
        val songB = createDummySong("B")
        val songs = listOf(songA, songB)

        coordinator.playQueue(songs, 0)
        advanceUntilIdle()

        // If queue changes and song A is re-played, warming is not blocked
        coordinator.playStandaloneItem(songA)
        advanceUntilIdle()

        assertEquals(songA.id, coordinator.currentSong.value?.id)
        assertTrue(coordinator.queue.value.isNotEmpty())
    }

    @Test
    fun testO_prefetchStaleGeneration_resetsPrefetchMarker() = runTest(testDispatcher) {
        val songA = createDummySong("A")
        val songB = createDummySong("B")
        val songC = createDummySong("C")

        coordinator.playQueue(listOf(songA, songB, songC), 0)
        advanceUntilIdle()

        // Queue reordered
        coordinator.moveInQueue(1, 2)
        advanceUntilIdle()

        assertEquals("A", coordinator.currentSong.value?.id)
        assertEquals("C", coordinator.queue.value[1].id)
    }

    @Test
    fun testP_preloadBenchmarkLiveMeasurementHarness() = runTest(testDispatcher) {
        val runner = PreloadBenchmarkRunner(fakeResolver)
        val testSongs = (1..10).map { createDummySong("bench_$it") }

        val comparison = runner.runComparativeBenchmark(testSongs, iterations = 20)
        assertNotNull(comparison.customStrategyResult)
        assertNotNull(comparison.media3StrategyResult)
        assertEquals("CustomBoundedLruPreloader", comparison.customStrategyResult.strategyName)
        assertEquals("Media3DefaultPreloadManager", comparison.media3StrategyResult.strategyName)
        assertTrue("Hit ratio should be >= 0", comparison.customStrategyResult.cacheHitRatio >= 0.0f)
        assertTrue("Mean next track gap should be measured", comparison.customStrategyResult.meanNextTrackGapMs >= 0.0)
        assertTrue("Media3 mean gap should be measured", comparison.media3StrategyResult.meanNextTrackGapMs >= 0.0)
    }

    @Test
    fun testQ_atomicSingleQueueStateObservation() = runTest(testDispatcher) {
        val songs = (1..5).map { createDummySong("atomic_$it") }
        coordinator.setQueue(songs, "atomic_3")
        advanceUntilIdle()

        val state = coordinator.queueState.value
        assertEquals("atomic_3", state.currentSong?.id)
        assertEquals(2, state.currentIndex)
        assertEquals(5, state.songs.size)
        assertEquals(state.currentSong?.id, coordinator.currentSong.value?.id)
        assertEquals(state.currentIndex, coordinator.currentIndex.value)
    }

    @Test
    fun testR_positionCheckpointSeparation() = runTest(testDispatcher) {
        val songs = listOf(createDummySong("1"), createDummySong("2"))
        coordinator.setQueue(songs, "1")
        advanceUntilIdle()

        // Simulate playback progress and pause checkpoint
        coordinator.seekTo(45000L)
        coordinator.pause()
        advanceUntilIdle()

        // Assert position checkpoint preserved
        assertEquals(45000L, fakeQueueStore.savedPositionMs)
        assertEquals(2, fakeQueueStore.savedSongs.size)
    }

    @Test
    fun testS_interleavedAsyncResolversWithOutOfOrderCompletion() = runTest(testDispatcher) {
        val defA = CompletableDeferred<StreamingResult?>()
        val defB = CompletableDeferred<StreamingResult?>()
        val defC = CompletableDeferred<StreamingResult?>()

        val songA = createDummySong("A")
        val songB = createDummySong("B")
        val songC = createDummySong("C")

        // 1. Play A
        fakeResolver.manualDeferred = defA
        coordinator.playStandaloneItem(songA)
        advanceUntilIdle()

        // 2. Play B
        fakeResolver.manualDeferred = defB
        coordinator.playStandaloneItem(songB)
        advanceUntilIdle()

        // 3. Play C
        fakeResolver.manualDeferred = defC
        coordinator.playStandaloneItem(songC)
        advanceUntilIdle()

        // 4. Complete B, then A, then C in reverse order
        defB.complete(StreamingResult("https://cdn.example.com/B.m4a", null, emptyMap()))
        advanceUntilIdle()
        assertNotEquals("B", coordinator.currentSong.value?.id)

        defA.complete(StreamingResult("https://cdn.example.com/A.m4a", null, emptyMap()))
        advanceUntilIdle()
        assertNotEquals("A", coordinator.currentSong.value?.id)

        defC.complete(StreamingResult("https://cdn.example.com/C.m4a", null, emptyMap()))
        advanceUntilIdle()
        assertEquals("C", coordinator.currentSong.value?.id)
        assertEquals(PlaybackStatus.PLAYING, coordinator.playbackStatus.value)
    }

    @Test
    fun testT_chaosRandomizedAsyncEventsAndInterruptions() = runTest(testDispatcher) {
        val testSongs = (1..20).map { createDummySong("chaos_$it") }
        coordinator.playQueue(testSongs, 0)
        advanceUntilIdle()

        val rng = java.util.Random(12345)
        for (step in 1..2000) {
            when (rng.nextInt(10)) {
                0 -> coordinator.play()
                1 -> coordinator.pause()
                2 -> coordinator.playNext()
                3 -> coordinator.playPrevious()
                4 -> coordinator.seekTo(rng.nextInt(180000).toLong())
                5 -> coordinator.toggleShuffle()
                6 -> coordinator.toggleRepeat()
                7 -> fakeEngine.triggerEnded()
                8 -> fakeEngine.triggerError(rng.nextInt(500), "Random error")
                9 -> coordinator.addToQueue(createDummySong("dyn_${step}"))
            }
            advanceUntilIdle()

            // Invariant check on every step
            val state = coordinator.queueState.value
            if (state.songs.isEmpty()) {
                assertEquals(-1, state.currentIndex)
                assertNull(state.currentSong)
            } else {
                assertTrue(state.currentIndex in state.songs.indices)
                assertEquals(state.songs[state.currentIndex].id, state.currentSong?.id)
            }
        }
    }

    @Test
    fun testU_adversarialAsyncCompletionOrderChaos() = runTest(testDispatcher) {
        val deferredMap = mutableMapOf<String, CompletableDeferred<StreamingResult?>>()
        val testSongs = (1..10).map { createDummySong("adv_$it") }
        coordinator.setQueue(testSongs, "adv_1")
        advanceUntilIdle()

        for (i in 1..20) {
            val song = testSongs[i % testSongs.size]
            val def = CompletableDeferred<StreamingResult?>()
            deferredMap[song.id] = def
            fakeResolver.manualDeferred = def

            coordinator.playSong(song)
            advanceUntilIdle()

            // Randomly complete an older deferred out of order
            val randomKey = deferredMap.keys.random()
            deferredMap[randomKey]?.complete(StreamingResult("https://cdn.example.com/$randomKey.m4a", null, emptyMap()))
            deferredMap.remove(randomKey)
            advanceUntilIdle()
        }

        // Finish remaining in-flight
        deferredMap.values.forEach { it.complete(StreamingResult("https://cdn.example.com/done.m4a", null, emptyMap())) }
        advanceUntilIdle()

        val state = coordinator.queueState.value
        assertNotNull(state.currentSong)
        assertTrue(state.currentIndex in state.songs.indices)
        assertEquals(state.songs[state.currentIndex].id, state.currentSong?.id)
    }

    @Test
    fun testV_shuffleSessionReconciliationAndPlayNextOverrideLifecycle() = runTest(testDispatcher) {
        val songs = listOf(
            createDummySong("1"),
            createDummySong("2"),
            createDummySong("3"),
            createDummySong("4")
        )
        coordinator.setQueue(songs, "1")
        advanceUntilIdle()

        // 1. Play Next Bonus Track
        val bonus = createDummySong("Bonus")
        coordinator.playNextInQueue(bonus)
        advanceUntilIdle()
        assertEquals("Bonus", coordinator.queue.value[1].id)

        // 2. Advance to Bonus track -> consumed override
        coordinator.playNext()
        advanceUntilIdle()
        assertEquals("Bonus", coordinator.currentSong.value?.id)

        // 3. Advance past Bonus track -> consumed
        coordinator.playNext()
        advanceUntilIdle()
        assertEquals("2", coordinator.currentSong.value?.id)

        // 4. Toggle Shuffle ON -> then move track -> Toggle Shuffle OFF
        coordinator.toggleShuffle()
        advanceUntilIdle()
        assertTrue(coordinator.isShuffleEnabled.value)

        coordinator.moveInQueue(1, 2)
        advanceUntilIdle()

        coordinator.toggleShuffle()
        advanceUntilIdle()
        assertFalse(coordinator.isShuffleEnabled.value)

        // Canonical structure remains pristine
        val canonicalIds = coordinator.canonicalQueue.value.map { it.id }.filter { it in listOf("1", "2", "3", "4") }
        assertEquals(listOf("1", "2", "3", "4"), canonicalIds)
    }
}

