package app.spasiba.nativeapp2.player

import app.spasiba.nativeapp2.data.model.Song
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Lightweight Derived StateFlow mapping directly to the underlying atomic StateFlow.
 * Eliminates out-of-sync multi-state issues by deriving .value synchronously.
 */
class DerivedStateFlow<T>(
    private val source: StateFlow<PlaybackQueueState>,
    private val selector: (PlaybackQueueState) -> T
) : StateFlow<T> {
    override val value: T get() = selector(source.value)
    override val replayCache: List<T> get() = listOf(value)
    override suspend fun collect(collector: FlowCollector<T>): Nothing {
        source.map(selector).distinctUntilChanged().collect(collector)
        awaitCancellation()
    }
}

/**
 * Thread-safe, serialized, deterministic Queue Controller.
 * Single synchronization path: all mutations MUST pass through queueMutex.withLock.
 * Persistence scheduling is strictly executed OUTSIDE the Mutex lock.
 */
class QueueController(
    private val queueStore: QueueStore,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val mainDispatcher: CoroutineDispatcher = Dispatchers.Main
) {
    companion object {
        const val MAX_QUEUE_TRACKS = 80
    }

    private val queueMutex = Mutex()
    var queueDebounceMs: Long = 400L
    private var persistQueueJob: Job? = null
    var queueGeneration: Long = 0L

    // The SINGLE Authoritative Observable Queue State
    val _queueState = MutableStateFlow(PlaybackQueueState())
    val queueState: StateFlow<PlaybackQueueState> = _queueState.asStateFlow()

    // Derived reactive flows from the single authoritative state
    val currentSong: StateFlow<Song?> = DerivedStateFlow(queueState) { it.currentSong }
    val queue: StateFlow<List<Song>> = DerivedStateFlow(queueState) { it.songs }
    val currentIndex: StateFlow<Int> = DerivedStateFlow(queueState) { it.currentIndex }
    val canonicalQueue: StateFlow<List<Song>> = DerivedStateFlow(queueState) { it.canonicalQueue }
    val isShuffleEnabled: StateFlow<Boolean> = DerivedStateFlow(queueState) { it.isShuffleEnabled }

    // Direct synchronous accessors
    val currentSongValue: Song? get() = _queueState.value.currentSong
    val queueValue: List<Song> get() = _queueState.value.songs
    val currentIndexValue: Int get() = _queueState.value.currentIndex
    val canonicalQueueValue: List<Song> get() = _queueState.value.canonicalQueue
    val isShuffleEnabledValue: Boolean get() = _queueState.value.isShuffleEnabled

    /**
     * The SOLE Authoritative mutation block.
     * State is computed and committed inside the Mutex lock; persistence is scheduled OUTSIDE.
     */
    suspend fun mutateQueue(transform: (PlaybackQueueState) -> PlaybackQueueState): PlaybackQueueState {
        val finalState = queueMutex.withLock {
            val currentState = _queueState.value
            val intermediate = transform(currentState)
            val safeSongs = intermediate.songs.take(MAX_QUEUE_TRACKS)
            val safeIndex = if (safeSongs.isEmpty()) -1 else intermediate.currentIndex.coerceIn(0, safeSongs.lastIndex)
            val safeSong = if (safeIndex in safeSongs.indices) safeSongs[safeIndex] else null
            val safeCanonical = intermediate.canonicalQueue.take(MAX_QUEUE_TRACKS)

            val nextGen = ++queueGeneration
            val state = intermediate.copy(
                songs = safeSongs,
                currentIndex = safeIndex,
                currentSong = safeSong,
                canonicalQueue = safeCanonical,
                queueGeneration = nextGen
            )
            _queueState.value = state
            state
        }
        // Critical: Lock is released before triggering async persistence job!
        persistQueueSnapshot(finalState)
        return finalState
    }

    private fun persistQueueSnapshot(state: PlaybackQueueState) {
        persistQueueJob?.cancel()
        persistQueueJob = scope.launch(ioDispatcher) {
            if (queueDebounceMs > 0L) {
                delay(queueDebounceMs)
            }
            queueStore.saveSnapshot(state.songs, state.currentIndex, 0L)
        }
    }

    fun persistPositionCheckpoint(positionMs: Long) {
        persistQueueJob?.cancel()
        val curState = _queueState.value
        persistQueueJob = scope.launch(ioDispatcher) {
            queueStore.saveSnapshot(curState.songs, curState.currentIndex, positionMs)
        }
    }

    fun enforceQueueCap(list: List<Song>, targetIndex: Int): Pair<List<Song>, Int> {
        if (list.size <= MAX_QUEUE_TRACKS) return Pair(list, targetIndex)
        val excess = list.size - MAX_QUEUE_TRACKS
        val dropFromStart = excess.coerceAtMost((targetIndex - 5).coerceAtLeast(0))
        val pruned = list.drop(dropFromStart).take(MAX_QUEUE_TRACKS)
        val newIdx = (targetIndex - dropFromStart).coerceIn(0, pruned.lastIndex.coerceAtLeast(0))
        return Pair(pruned, newIdx)
    }

    suspend fun setQueue(tracks: List<Song>, activeSongId: String?, isShuffle: Boolean = false): Song? {
        val cleanTracks = tracks.distinctBy { it.id }.take(MAX_QUEUE_TRACKS)
        if (cleanTracks.isEmpty()) {
            mutateQueue {
                PlaybackQueueState(
                    songs = emptyList(),
                    currentIndex = -1,
                    currentSong = null,
                    canonicalQueue = emptyList(),
                    isShuffleEnabled = isShuffle,
                    shuffleSession = null
                )
            }
            return null
        }

        val targetId = activeSongId ?: cleanTracks.first().id
        val activeIdx = cleanTracks.indexOfFirst { it.id == targetId }.coerceAtLeast(0)
        val activeSong = cleanTracks[activeIdx]

        if (isShuffle && cleanTracks.size > 1) {
            val upcoming = cleanTracks.filter { it.id != activeSong.id }.shuffled()
            val playbackList = listOf(activeSong) + upcoming
            val session = ShuffleSession(
                originalCanonicalIds = cleanTracks.map { it.id },
                playbackOrder = playbackList.map { it.id }
            )
            mutateQueue {
                it.copy(
                    songs = playbackList,
                    currentIndex = 0,
                    currentSong = activeSong,
                    canonicalQueue = cleanTracks,
                    isShuffleEnabled = true,
                    shuffleSession = session
                )
            }
            return activeSong
        } else {
            mutateQueue {
                it.copy(
                    songs = cleanTracks,
                    currentIndex = activeIdx,
                    currentSong = activeSong,
                    canonicalQueue = cleanTracks,
                    isShuffleEnabled = false,
                    shuffleSession = null
                )
            }
            return activeSong
        }
    }

    suspend fun addToQueue(song: Song) {
        mutateQueue { state ->
            val currentList = state.songs.toMutableList()
            val canonicalList = state.canonicalQueue.toMutableList()

            if (!currentList.any { it.id == song.id }) {
                currentList.add(song)
            }
            if (!canonicalList.any { it.id == song.id }) {
                canonicalList.add(song)
            }

            val curIdx = state.currentIndex.coerceAtLeast(0)
            val canonicalActiveIdx = if (state.currentSong != null) {
                canonicalList.indexOfFirst { it.id == state.currentSong.id }.coerceAtLeast(0)
            } else {
                curIdx
            }

            val (cappedList, newCurIdx) = enforceQueueCap(currentList, curIdx)
            val (cappedCanonical, _) = enforceQueueCap(canonicalList, canonicalActiveIdx)
            val targetSong = state.currentSong ?: cappedList.firstOrNull()

            val updatedSession = state.shuffleSession?.copy(
                playbackOrder = cappedList.map { it.id },
                originalCanonicalIds = cappedCanonical.map { it.id }
            )

            state.copy(
                songs = cappedList,
                currentIndex = newCurIdx,
                currentSong = targetSong,
                canonicalQueue = cappedCanonical,
                shuffleSession = updatedSession
            )
        }
    }

    /**
     * Play Next Semantics:
     * - playbackOrder / songs: Inserts song immediately after current playing track.
     * - canonicalQueue: 100% UNCHANGED (preserves master playlist ordering intact).
     * - temporaryPlayNextIds: Records the temporary override for deterministic lifecycle tracking.
     */
    suspend fun playNextInQueue(song: Song) {
        mutateQueue { state ->
            val currentList = state.songs.toMutableList()
            currentList.removeAll { it.id == song.id }
            val insertIndex = (state.currentIndex + 1).coerceIn(0, currentList.size)
            currentList.add(insertIndex, song)

            val curIdx = state.currentIndex.coerceAtLeast(0)
            val (cappedList, newCurIdx) = enforceQueueCap(currentList, curIdx)
            val targetSong = state.currentSong ?: cappedList.firstOrNull()

            val updatedSession = state.shuffleSession?.copy(
                playbackOrder = cappedList.map { it.id },
                temporaryPlayNextIds = (state.shuffleSession.temporaryPlayNextIds + song.id).distinct()
            ) ?: ShuffleSession(
                playbackOrder = cappedList.map { it.id },
                temporaryPlayNextIds = listOf(song.id)
            )

            state.copy(
                songs = cappedList,
                currentIndex = newCurIdx,
                currentSong = targetSong,
                canonicalQueue = state.canonicalQueue,
                shuffleSession = updatedSession
            )
        }
    }

    suspend fun removeFromQueue(index: Int): Pair<Song?, Boolean> {
        var removedCurrent = false
        var nextSongToPlay: Song? = null

        mutateQueue { state ->
            val currentList = state.songs.toMutableList()
            val canonicalList = state.canonicalQueue.toMutableList()

            if (index !in currentList.indices) return@mutateQueue state

            val removedItem = currentList.removeAt(index)
            canonicalList.removeAll { it.id == removedItem.id }
            val isCurrent = (index == state.currentIndex)
            removedCurrent = isCurrent

            val updatedSession = state.shuffleSession?.copy(
                playbackOrder = currentList.map { it.id },
                originalCanonicalIds = canonicalList.map { it.id },
                temporaryPlayNextIds = state.shuffleSession.temporaryPlayNextIds - removedItem.id
            )

            if (isCurrent) {
                if (currentList.isNotEmpty()) {
                    val nextIdx = index.coerceAtMost(currentList.lastIndex)
                    nextSongToPlay = currentList[nextIdx]
                    state.copy(
                        songs = currentList,
                        currentIndex = nextIdx,
                        currentSong = nextSongToPlay,
                        canonicalQueue = canonicalList,
                        shuffleSession = updatedSession
                    )
                } else {
                    nextSongToPlay = null
                    state.copy(
                        songs = emptyList(),
                        currentIndex = -1,
                        currentSong = null,
                        canonicalQueue = emptyList(),
                        shuffleSession = null
                    )
                }
            } else {
                val currentId = state.currentSong?.id
                val newIdx = if (currentId != null) currentList.indexOfFirst { it.id == currentId } else -1
                val curSong = if (newIdx in currentList.indices) currentList[newIdx] else null
                nextSongToPlay = curSong
                state.copy(
                    songs = currentList,
                    currentIndex = newIdx,
                    currentSong = curSong,
                    canonicalQueue = canonicalList,
                    shuffleSession = updatedSession
                )
            }
        }
        return Pair(nextSongToPlay, removedCurrent)
    }

    suspend fun moveInQueue(fromIndex: Int, toIndex: Int) {
        mutateQueue { state ->
            val currentList = state.songs.toMutableList()
            if (fromIndex in currentList.indices && toIndex in currentList.indices) {
                val item = currentList.removeAt(fromIndex)
                currentList.add(toIndex, item)
                val currentId = state.currentSong?.id
                val newIdx = if (currentId != null) currentList.indexOfFirst { it.id == currentId } else -1

                val updatedCanonical = if (!state.isShuffleEnabled) currentList.toList() else state.canonicalQueue
                val updatedSession = state.shuffleSession?.copy(playbackOrder = currentList.map { it.id })
                state.copy(
                    songs = currentList,
                    currentIndex = newIdx,
                    canonicalQueue = updatedCanonical,
                    shuffleSession = updatedSession
                )
            } else {
                state
            }
        }
    }

    suspend fun toggleShuffle() {
        mutateQueue { state ->
            val currentQ = state.songs
            val curIdx = state.currentIndex
            val currentSongItem = state.currentSong
            if (currentQ.size <= 1) {
                return@mutateQueue state.copy(isShuffleEnabled = !state.isShuffleEnabled)
            }

            val willBeShuffle = !state.isShuffleEnabled
            if (willBeShuffle) {
                val canonical = if (state.canonicalQueue.isNotEmpty()) state.canonicalQueue else currentQ
                val history = currentQ.take(curIdx.coerceAtLeast(0))
                val upcoming = currentQ.drop(curIdx + 1).shuffled()
                val newQ = if (currentSongItem != null) history + listOf(currentSongItem) + upcoming else currentQ.shuffled()
                val newIdx = if (currentSongItem != null) newQ.indexOfFirst { it.id == currentSongItem.id } else 0
                val session = ShuffleSession(
                    originalCanonicalIds = canonical.map { it.id },
                    playbackOrder = newQ.map { it.id },
                    temporaryPlayNextIds = state.shuffleSession?.temporaryPlayNextIds ?: emptyList()
                )
                state.copy(
                    songs = newQ,
                    currentIndex = newIdx,
                    currentSong = currentSongItem,
                    canonicalQueue = canonical,
                    isShuffleEnabled = true,
                    shuffleSession = session
                )
            } else {
                val canonical = if (state.canonicalQueue.isNotEmpty()) state.canonicalQueue else currentQ
                val newIdx = if (currentSongItem != null) canonical.indexOfFirst { it.id == currentSongItem.id }.coerceAtLeast(0) else 0
                val newSong = if (newIdx in canonical.indices) canonical[newIdx] else null
                state.copy(
                    songs = canonical,
                    currentIndex = newIdx,
                    currentSong = newSong,
                    canonicalQueue = canonical,
                    isShuffleEnabled = false,
                    shuffleSession = null
                )
            }
        }
    }

    /**
     * Unified Next-Decision Engine: Single authority deciding what plays next.
     * Consumes temporary PlayNext overrides deterministically.
     */
    suspend fun resolveNextPlaybackDecision(reason: NextTrackReason): PlaybackDecision {
        var decision: PlaybackDecision = PlaybackDecision.EndOfQueue

        mutateQueue { state ->
            val currentQ = state.songs
            val curIdx = state.currentIndex
            val currentSongItem = state.currentSong

            if (currentQ.isEmpty()) {
                decision = PlaybackDecision.Stop
                return@mutateQueue state
            }

            // Deterministically consume consumed PlayNext override
            val cleanedSession = if (currentSongItem != null && state.shuffleSession != null) {
                state.shuffleSession.copy(
                    temporaryPlayNextIds = state.shuffleSession.temporaryPlayNextIds - currentSongItem.id
                )
            } else {
                state.shuffleSession
            }

            when (reason) {
                NextTrackReason.TRACK_ENDED -> {
                    if (state.repeatState == RepeatState.ONE && currentSongItem != null) {
                        decision = PlaybackDecision.ReplayCurrent(currentSongItem)
                        return@mutateQueue state.copy(shuffleSession = cleanedSession)
                    }
                    val nextIdx = curIdx + 1
                    if (nextIdx in currentQ.indices) {
                        val nextSong = currentQ[nextIdx]
                        decision = PlaybackDecision.Play(nextSong, 0L)
                        state.copy(currentIndex = nextIdx, currentSong = nextSong, shuffleSession = cleanedSession)
                    } else if (state.repeatState == RepeatState.ALL && currentQ.isNotEmpty()) {
                        val wrapSong = currentQ[0]
                        decision = PlaybackDecision.Play(wrapSong, 0L)
                        state.copy(currentIndex = 0, currentSong = wrapSong, shuffleSession = cleanedSession)
                    } else {
                        decision = PlaybackDecision.EndOfQueue
                        state.copy(shuffleSession = cleanedSession)
                    }
                }
                NextTrackReason.USER_NEXT, NextTrackReason.REMOVE_CURRENT, NextTrackReason.AUTOPLAY, NextTrackReason.RADIO_CONTINUATION -> {
                    val nextIdx = curIdx + 1
                    if (nextIdx in currentQ.indices) {
                        val nextSong = currentQ[nextIdx]
                        decision = PlaybackDecision.Play(nextSong, 0L)
                        state.copy(currentIndex = nextIdx, currentSong = nextSong, shuffleSession = cleanedSession)
                    } else if (state.repeatState == RepeatState.ALL && currentQ.isNotEmpty()) {
                        val wrapSong = currentQ[0]
                        decision = PlaybackDecision.Play(wrapSong, 0L)
                        state.copy(currentIndex = 0, currentSong = wrapSong, shuffleSession = cleanedSession)
                    } else {
                        decision = PlaybackDecision.EndOfQueue
                        state.copy(shuffleSession = cleanedSession)
                    }
                }
                NextTrackReason.USER_PREVIOUS -> {
                    val prevIdx = curIdx - 1
                    if (prevIdx in currentQ.indices) {
                        val prevSong = currentQ[prevIdx]
                        decision = PlaybackDecision.Play(prevSong, 0L)
                        state.copy(currentIndex = prevIdx, currentSong = prevSong, shuffleSession = cleanedSession)
                    } else if (state.repeatState == RepeatState.ALL && currentQ.isNotEmpty()) {
                        val wrapSong = currentQ.last()
                        decision = PlaybackDecision.Play(wrapSong, 0L)
                        state.copy(currentIndex = currentQ.lastIndex, currentSong = wrapSong, shuffleSession = cleanedSession)
                    } else {
                        val cur = currentSongItem ?: currentQ[0]
                        decision = PlaybackDecision.Play(cur, 0L)
                        state.copy(shuffleSession = cleanedSession)
                    }
                }
            }
        }

        return decision
    }

    suspend fun selectQueueItem(songId: String): Song? {
        var selected: Song? = null
        mutateQueue { state ->
            val idx = state.songs.indexOfFirst { it.id == songId }
            if (idx in state.songs.indices) {
                selected = state.songs[idx]
                state.copy(currentIndex = idx, currentSong = selected)
            } else {
                state
            }
        }
        return selected
    }

    suspend fun toggleRepeat(): RepeatState {
        var nextRepeat = RepeatState.OFF
        mutateQueue { state ->
            nextRepeat = when (state.repeatState) {
                RepeatState.OFF -> RepeatState.ALL
                RepeatState.ALL -> RepeatState.ONE
                RepeatState.ONE -> RepeatState.OFF
            }
            state.copy(repeatState = nextRepeat)
        }
        return nextRepeat
    }

    suspend fun clear() {
        mutateQueue {
            PlaybackQueueState(
                songs = emptyList(),
                currentIndex = -1,
                currentSong = null,
                canonicalQueue = emptyList(),
                isShuffleEnabled = false,
                shuffleSession = null
            )
        }
    }
}
