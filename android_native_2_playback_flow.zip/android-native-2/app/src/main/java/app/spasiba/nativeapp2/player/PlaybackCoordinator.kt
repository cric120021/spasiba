package app.spasiba.nativeapp2.player

import app.spasiba.nativeapp2.data.model.Song
import app.spasiba.nativeapp2.data.repository.LyricLine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Production-Grade Playback Coordinator.
 * Orchestrates QueueController, RecoveryController, PreloadController, LyricsController, and PlayerEngine.
 * Contains a strictly serialized Playback Command Channel and unified Next-Decision Engine.
 */
open class PlaybackCoordinator(
    val engine: PlayerEngine,
    val resolver: StreamResolver,
    val queueStore: QueueStore,
    val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main),
    val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    val mainDispatcher: CoroutineDispatcher = Dispatchers.Main
) {
    companion object {
        const val RESTART_PREVIOUS_AFTER_MS = 3000L
    }

    // Modular Subsystem Controllers
    val queueController = QueueController(queueStore, scope, ioDispatcher, mainDispatcher)
    val recoveryController = RecoveryController(resolver, scope, ioDispatcher, mainDispatcher)
    val preloadController = PreloadController(resolver, scope, ioDispatcher, mainDispatcher)
    val lyricsController = LyricsController(resolver, scope, ioDispatcher, mainDispatcher)

    // Serialized Command Channel preventing concurrency races
    private val commandChannel = Channel<PlaybackAction>(Channel.UNLIMITED)

    // Job Holders for direct cancellation
    var playbackJob: Job? = null
    var videoJob: Job? = null
    var progressJob: Job? = null

    // Generational Transaction Barriers
    var playbackGeneration: Long = 0L
    val queueGeneration: Long get() = queueController.queueGeneration
    var pendingSeekPosition: Long? = null
    var hasTriggered70Percent: Boolean = false

    // Authoritative User Intent
    var desiredPlaybackState = DesiredPlaybackState.STOPPED
    var progressTickerEnabled: Boolean = true

    // StateFlows forwarded from QueueController
    val queueState: StateFlow<PlaybackQueueState> = queueController.queueState
    val currentSong: StateFlow<Song?> = queueController.currentSong
    val queue: StateFlow<List<Song>> = queueController.queue
    val currentIndex: StateFlow<Int> = queueController.currentIndex
    val canonicalQueue: StateFlow<List<Song>> = queueController.canonicalQueue
    val isShuffleEnabled: StateFlow<Boolean> = queueController.isShuffleEnabled

    // Playback state flows
    val _playbackStatus = MutableStateFlow(PlaybackStatus.IDLE)
    val playbackStatus: StateFlow<PlaybackStatus> = _playbackStatus.asStateFlow()

    val _queueSourceLabel = MutableStateFlow("Spasiba Radio")
    val queueSourceLabel: StateFlow<String> = _queueSourceLabel.asStateFlow()

    val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    val _repeatState = MutableStateFlow(RepeatState.OFF)
    val repeatState: StateFlow<RepeatState> = _repeatState.asStateFlow()

    // Lyrics flows forwarded from LyricsController
    val currentLyrics: StateFlow<String?> = lyricsController.currentLyrics
    val syncedLyrics: StateFlow<List<LyricLine>> = lyricsController.syncedLyrics
    val isLyricsLoading: StateFlow<Boolean> = lyricsController.isLyricsLoading

    // Video Mode State
    var isVideoModeActive: Boolean = false
    val _currentVideoQuality = MutableStateFlow("720p")
    val currentVideoQuality: StateFlow<String> = _currentVideoQuality.asStateFlow()
    val videoQuality: StateFlow<String> = _currentVideoQuality.asStateFlow()
    val _availableVideoQualities = MutableStateFlow(listOf("360p", "480p", "720p", "1080p"))
    val availableVideoQualities: StateFlow<List<String>> = _availableVideoQualities.asStateFlow()

    val _videoAspectRatio = MutableStateFlow(16f / 9f)
    val videoAspectRatio: StateFlow<Float> = _videoAspectRatio.asStateFlow()

    // Remote Action Listeners
    var eunoiaPlaybackActionListener: ((action: String, payload: org.json.JSONObject?) -> Unit)? = null
    var eunoiaTrackChangeListener: ((song: Song) -> Unit)? = null

    // Compatibility accessors
    var queueDebounceMs: Long
        get() = queueController.queueDebounceMs
        set(value) { queueController.queueDebounceMs = value }

    val preResolvedStreamMap get() = preloadController.preResolvedStreamMap
    val resolvedVideoIdMap get() = preloadController.resolvedVideoIdMap
    val lyricsMemoryCache get() = lyricsController.lyricsMemoryCache
    val retryAttempts get() = recoveryController.retryAttempts

    var prefetchedVideoId: String?
        get() = preloadController.prefetchedVideoId
        set(value) { preloadController.prefetchedVideoId = value }

    var lastWarmedSongId: String?
        get() = preloadController.lastWarmedSongId
        set(value) { preloadController.lastWarmedSongId = value }

    var lastLoadedLyricsSongId: String?
        get() = lyricsController.lastLoadedLyricsSongId
        set(value) { lyricsController.lastLoadedLyricsSongId = value }

    init {
        // Start Command Processing Loop
        scope.launch(mainDispatcher) {
            for (action in commandChannel) {
                processAction(action)
            }
        }

        engine.setListener(object : PlayerEngine.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    PlayerEngine.STATE_BUFFERING -> {
                        _isLoading.value = true
                        _playbackStatus.value = PlaybackStatus.BUFFERING
                    }
                    PlayerEngine.STATE_READY -> {
                        _isLoading.value = false
                        val dur = engine.duration
                        if (dur > 0L) {
                            _durationMs.value = dur
                        }
                        _playbackStatus.value = if (engine.isPlaying) PlaybackStatus.PLAYING else PlaybackStatus.PAUSED
                        if (engine.isPlaying) {
                            startProgressTicker()
                        }
                    }
                    PlayerEngine.STATE_ENDED -> {
                        handleTrackEnded()
                    }
                    PlayerEngine.STATE_IDLE -> {
                        if (desiredPlaybackState == DesiredPlaybackState.STOPPED) {
                            _playbackStatus.value = PlaybackStatus.IDLE
                        }
                        stopProgressTicker()
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
                if (isPlaying) {
                    _playbackStatus.value = PlaybackStatus.PLAYING
                    val curId = queueController.currentSongValue?.id
                    if (curId != null) recoveryController.resetRetries(curId)
                    startProgressTicker()
                } else {
                    if (_playbackStatus.value == PlaybackStatus.PLAYING) {
                        _playbackStatus.value = PlaybackStatus.PAUSED
                    }
                    stopProgressTicker()
                    savePositionCheckpoint()
                }
                eunoiaPlaybackActionListener?.invoke(if (isPlaying) "play" else "pause", org.json.JSONObject().apply {
                    put("positionMs", engine.currentPosition.coerceAtLeast(0L))
                    put("isPlaying", isPlaying)
                })
            }

            override fun onVideoSizeChanged(width: Int, height: Int) {
                if (width > 0 && height > 0) {
                    val calculatedRatio = width.toFloat() / height.toFloat()
                    val safeRatio = calculatedRatio.coerceIn(0.55f, 2.2f)
                    _videoAspectRatio.value = safeRatio
                }
            }

            override fun onPlayerError(errorCode: Int, message: String?) {
                val current = queueController.currentSongValue ?: return
                val currentPos = _positionMs.value.coerceAtLeast(0L)
                val generation = playbackGeneration

                _isLoading.value = true
                _playbackStatus.value = PlaybackStatus.RECOVERING
                preloadController.preResolvedStreamMap.remove(current.id)

                recoveryController.attemptRecovery(
                    currentSong = current,
                    currentPosMs = currentPos,
                    generation = generation,
                    resolvedVideoId = preloadController.resolvedVideoIdMap[current.id],
                    isGenerationValid = { it == playbackGeneration },
                    isSongActive = { queueController.currentSongValue?.id == it },
                    onSuccess = { freshResult, updatedSong, seekPos ->
                        preloadController.cacheStreamResult(updatedSong.id, null, freshResult)
                        scope.launch(mainDispatcher) {
                            queueController.mutateQueue { state ->
                                val liveSongs = state.songs
                                val updatedList = liveSongs.map { if (it.id == updatedSong.id) updatedSong else it }
                                val liveIdx = updatedList.indexOfFirst { it.id == updatedSong.id }
                                state.copy(songs = updatedList, currentIndex = liveIdx, currentSong = updatedSong)
                            }
                        }

                        engine.setMediaSource(freshResult.url, updatedSong, freshResult.headers, freshResult.url.startsWith("/"))
                        engine.prepare()
                        if (seekPos > 0L) engine.seekTo(seekPos)

                        if (desiredPlaybackState == DesiredPlaybackState.PLAYING) {
                            engine.play()
                            _isPlaying.value = true
                            _playbackStatus.value = PlaybackStatus.PLAYING
                        } else {
                            engine.pause()
                            _isPlaying.value = false
                            _playbackStatus.value = PlaybackStatus.PAUSED
                        }
                        _isLoading.value = false
                    },
                    onExhaustedOrFailed = {
                        _isLoading.value = false
                        _playbackStatus.value = PlaybackStatus.FAILED
                        playNext()
                    }
                )
            }
        })
    }

    private suspend fun processAction(action: PlaybackAction) {
        when (action) {
            is PlaybackAction.Play -> executePlayback(action.song, action.initialPosMs)
            is PlaybackAction.Resume -> {
                desiredPlaybackState = DesiredPlaybackState.PLAYING
                if (!engine.isPlaying) {
                    val song = queueController.currentSongValue
                    if (song != null) {
                        if (engine.playbackState == PlayerEngine.STATE_IDLE || engine.playbackState == PlayerEngine.STATE_ENDED) {
                            executePlayback(song, _positionMs.value)
                        } else {
                            engine.play()
                            _isPlaying.value = true
                            _playbackStatus.value = PlaybackStatus.PLAYING
                        }
                    } else if (queueController.queueValue.isNotEmpty()) {
                        val firstSong = queueController.queueValue[0]
                        executePlayback(firstSong, 0L)
                    }
                }
            }
            is PlaybackAction.Pause -> {
                desiredPlaybackState = DesiredPlaybackState.PAUSED
                if (engine.isPlaying || _isLoading.value) {
                    engine.pause()
                    _isPlaying.value = false
                    _playbackStatus.value = PlaybackStatus.PAUSED
                }
                savePositionCheckpoint()
            }
            is PlaybackAction.Stop -> {
                desiredPlaybackState = DesiredPlaybackState.STOPPED
                playbackJob?.cancel()
                videoJob?.cancel()
                recoveryController.cancelRecovery()
                savePositionCheckpoint()
                ++playbackGeneration
                engine.stop()
                _isPlaying.value = false
                _isLoading.value = false
                _playbackStatus.value = PlaybackStatus.IDLE
            }
            is PlaybackAction.Seek -> {
                val safePos = action.positionMs.coerceAtLeast(0L)
                _positionMs.value = safePos
                if (_isLoading.value || _playbackStatus.value == PlaybackStatus.RESOLVING) {
                    pendingSeekPosition = safePos
                } else {
                    engine.seekTo(safePos)
                }
            }
            is PlaybackAction.Next -> {
                val decision = queueController.resolveNextPlaybackDecision(NextTrackReason.USER_NEXT)
                dispatchPlaybackDecision(decision)
                maybeReplenishRadioQueue()
            }
            is PlaybackAction.Previous -> {
                if (_positionMs.value > RESTART_PREVIOUS_AFTER_MS) {
                    processAction(PlaybackAction.Seek(0L))
                } else {
                    val decision = queueController.resolveNextPlaybackDecision(NextTrackReason.USER_PREVIOUS)
                    dispatchPlaybackDecision(decision)
                }
            }
            is PlaybackAction.TrackEnded -> {
                if (action.generation == playbackGeneration && action.songId == queueController.currentSongValue?.id) {
                    val decision = queueController.resolveNextPlaybackDecision(NextTrackReason.TRACK_ENDED)
                    dispatchPlaybackDecision(decision)
                }
            }
            is PlaybackAction.TrackError -> {
                // Handled in player error callback
            }
            is PlaybackAction.SelectItem -> {
                val song = queueController.selectQueueItem(action.songId)
                if (song != null) {
                    executePlayback(song, 0L)
                }
            }
        }
    }

    fun savePositionCheckpoint() {
        val curPos = _positionMs.value
        queueController.persistPositionCheckpoint(curPos)
    }

    fun fetchLyricsForCurrentSong(force: Boolean = false) {
        lyricsController.fetchLyricsForSong(
            song = queueController.currentSongValue,
            generation = playbackGeneration,
            isGenerationValid = { it == playbackGeneration },
            isSongActive = { queueController.currentSongValue?.id == it },
            force = force
        )
    }

    fun warmSmartQueue() {
        val state = queueController._queueState.value
        preloadController.warmSmartQueue(
            currentTrack = state.currentSong,
            currentQueue = state.songs,
            currentIndex = state.currentIndex,
            queueGeneration = state.queueGeneration,
            playbackGeneration = playbackGeneration,
            isStateValid = { qGen, pGen, songId ->
                qGen == queueController.queueGeneration && pGen == playbackGeneration && queueController.currentSongValue?.id == songId
            },
            onNewTracksAppended = { newSongs, trackId ->
                scope.launch(mainDispatcher) {
                    queueController.mutateQueue { liveState ->
                        val updatedQueue = (liveState.songs + newSongs).take(QueueController.MAX_QUEUE_TRACKS)
                        val liveIdx = updatedQueue.indexOfFirst { it.id == trackId }.coerceAtLeast(0)
                        liveState.copy(
                            songs = updatedQueue,
                            currentIndex = liveIdx,
                            currentSong = liveState.currentSong,
                            canonicalQueue = liveState.canonicalQueue + newSongs
                        )
                    }
                }
            }
        )
    }

    fun prefetchNextStream() {
        val state = queueController._queueState.value
        val nextIndex = state.currentIndex + 1
        val nextTrack = if (nextIndex in state.songs.indices) state.songs[nextIndex] else null

        preloadController.prefetchNextStream(
            nextTrack = nextTrack,
            queueGeneration = state.queueGeneration,
            playbackGeneration = playbackGeneration,
            isStateValid = { qGen, pGen ->
                qGen == queueController.queueGeneration && pGen == playbackGeneration
            }
        )
    }

    fun maybePrefetchNextTrack() {
        warmSmartQueue()
        prefetchNextStream()
    }

    fun maybeReplenishRadioQueue() {
        val state = queueController._queueState.value
        val curIndex = state.currentIndex
        val curQueue = state.songs

        if (curIndex in curQueue.indices && curQueue.size - curIndex <= 2) {
            val currentTrack = curQueue[curIndex]
            preloadController.replenishRadioQueue(
                currentTrack = currentTrack,
                queueGeneration = state.queueGeneration,
                playbackGeneration = playbackGeneration,
                isStateValid = { qGen, pGen, songId ->
                    qGen == queueController.queueGeneration && pGen == playbackGeneration && queueController.currentSongValue?.id == songId
                },
                onRadioTracksReceived = { candidateTracks ->
                    scope.launch(mainDispatcher) {
                        queueController.mutateQueue { liveState ->
                            val liveIdx = liveState.songs.indexOfFirst { it.id == currentTrack.id }
                            if (liveIdx >= 0) {
                                val activeHistoryAndCurrent = liveState.songs.take(liveIdx + 1)
                                val deduplicated = candidateTracks.filter { cand ->
                                    !activeHistoryAndCurrent.any { it.id == cand.id }
                                }
                                val updatedQueue = (activeHistoryAndCurrent + deduplicated).take(liveIdx + 1 + 10)
                                if (updatedQueue.size > liveState.songs.size) {
                                    liveState.copy(
                                        songs = updatedQueue,
                                        currentIndex = liveIdx,
                                        currentSong = currentTrack,
                                        canonicalQueue = liveState.canonicalQueue + deduplicated
                                    )
                                } else {
                                    liveState
                                }
                            } else {
                                liveState
                            }
                        }
                    }
                }
            )
        }
    }

    open fun setQueue(tracks: List<Song>, activeSongId: String?, sourceLabel: String = "Spasiba Radio") {
        if (tracks.isEmpty()) {
            clearQueue()
            return
        }

        _queueSourceLabel.value = sourceLabel
        preloadController.prefetchedVideoId = null
        scope.launch(mainDispatcher) {
            queueController.setQueue(tracks, activeSongId, isShuffle = false)
        }
    }

    open fun playQueue(songs: List<Song>, startIndex: Int = 0, sourceLabel: String = "Spasiba Radio") {
        if (songs.isEmpty() || startIndex !in songs.indices) return
        val clickedSong = songs[startIndex]
        _queueSourceLabel.value = sourceLabel
        preloadController.prefetchedVideoId = null
        scope.launch(mainDispatcher) {
            queueController.setQueue(songs, clickedSong.id, isShuffle = false)
            commandChannel.send(PlaybackAction.Play(clickedSong, 0L))
        }
    }

    open fun playSingleSongWithRadio(clickedSong: Song, sourceLabel: String = "Spasiba Radio") {
        _queueSourceLabel.value = sourceLabel
        scope.launch(mainDispatcher) {
            queueController.setQueue(listOf(clickedSong), clickedSong.id, isShuffle = false)
            commandChannel.send(PlaybackAction.Play(clickedSong, 0L))

            val capturedGen = queueController.queueGeneration
            val capturedPlayGen = playbackGeneration

            preloadController.replenishRadioQueue(
                currentTrack = clickedSong,
                queueGeneration = capturedGen,
                playbackGeneration = capturedPlayGen,
                isStateValid = { qGen, pGen, songId ->
                    qGen == queueController.queueGeneration && pGen == playbackGeneration && queueController.currentSongValue?.id == songId
                },
                onRadioTracksReceived = { radioTracks ->
                    scope.launch(mainDispatcher) {
                        queueController.mutateQueue { liveState ->
                            val deduplicated = radioTracks.filter { cand -> !liveState.songs.any { it.id == cand.id } }
                            val updatedQueue = (liveState.songs + deduplicated).take(QueueController.MAX_QUEUE_TRACKS)
                            val liveIdx = updatedQueue.indexOfFirst { it.id == clickedSong.id }.coerceAtLeast(0)
                            liveState.copy(songs = updatedQueue, currentIndex = liveIdx, currentSong = clickedSong, canonicalQueue = updatedQueue)
                        }
                    }
                }
            )
        }
    }

    open fun playSong(song: Song, initialPosMs: Long = 0L) {
        val curQueue = queueController.queueValue
        val queueIdx = curQueue.indexOfFirst { it.id == song.id }
        if (queueIdx >= 0) {
            scope.launch(mainDispatcher) {
                queueController.selectQueueItem(song.id)
                commandChannel.send(PlaybackAction.Play(song, initialPosMs))
            }
        } else {
            playSingleSongWithRadio(song)
        }
    }

    open fun playStandaloneItem(song: Song, sourceLabel: String = "Spasiba Radio") {
        _queueSourceLabel.value = sourceLabel
        scope.launch(mainDispatcher) {
            queueController.setQueue(listOf(song), song.id, isShuffle = false)
            commandChannel.send(PlaybackAction.Play(song, 0L))
        }
    }

    open fun playQueueItem(songId: String) {
        scope.launch(mainDispatcher) {
            commandChannel.send(PlaybackAction.SelectItem(songId))
        }
    }

    open fun addToQueue(song: Song) {
        preloadController.prefetchedVideoId = null
        val wasEmpty = queueController.queueValue.isEmpty()
        scope.launch(mainDispatcher) {
            queueController.addToQueue(song)
            maybePrefetchNextTrack()
            if (wasEmpty && queueController.currentSongValue != null) {
                commandChannel.send(PlaybackAction.Play(queueController.currentSongValue!!, 0L))
            }
        }
    }

    open fun playNextInQueue(song: Song) {
        preloadController.prefetchedVideoId = null
        val wasEmpty = queueController.queueValue.isEmpty()
        scope.launch(mainDispatcher) {
            queueController.playNextInQueue(song)
            maybePrefetchNextTrack()
            if (wasEmpty && queueController.currentSongValue != null) {
                commandChannel.send(PlaybackAction.Play(queueController.currentSongValue!!, 0L))
            }
        }
    }

    open fun removeFromQueue(index: Int) {
        preloadController.prefetchedVideoId = null
        scope.launch(mainDispatcher) {
            val (nextSongToPlay, wasCurrentRemoved) = queueController.removeFromQueue(index)

            if (wasCurrentRemoved) {
                playbackJob?.cancel()
                videoJob?.cancel()
                recoveryController.cancelRecovery()
                ++playbackGeneration

                if (nextSongToPlay != null) {
                    commandChannel.send(PlaybackAction.Play(nextSongToPlay, 0L))
                } else {
                    clearQueue()
                }
            }
        }
    }

    open fun moveInQueue(fromIndex: Int, toIndex: Int) {
        preloadController.prefetchedVideoId = null
        scope.launch(mainDispatcher) {
            queueController.moveInQueue(fromIndex, toIndex)
        }
    }

    open fun clearQueue() {
        playbackJob?.cancel()
        videoJob?.cancel()
        recoveryController.cancelRecovery()
        preloadController.clear()
        lyricsController.clear()

        ++playbackGeneration
        desiredPlaybackState = DesiredPlaybackState.STOPPED
        pendingSeekPosition = null

        _isPlaying.value = false
        _isLoading.value = false
        _positionMs.value = 0L
        _durationMs.value = 0L
        _playbackStatus.value = PlaybackStatus.IDLE

        engine.stop()
        engine.clearMediaItems()
        scope.launch(mainDispatcher) {
            queueController.clear()
        }
    }

    open fun toggleShuffle() {
        preloadController.prefetchedVideoId = null
        scope.launch(mainDispatcher) {
            queueController.toggleShuffle()
        }
    }

    open fun toggleRepeat() {
        scope.launch(mainDispatcher) {
            val nextRepeat = queueController.toggleRepeat()
            _repeatState.value = nextRepeat
        }
    }

    open fun disableVideoMode() {
        isVideoModeActive = false
        videoJob?.cancel()
        val song = queueController.currentSongValue ?: return
        executePlayback(song, _positionMs.value)
    }

    open fun setVideoQuality(quality: String) {
        isVideoModeActive = true
        videoJob?.cancel()
        _currentVideoQuality.value = quality
        val song = queueController.currentSongValue ?: return
        startProgressiveVideoDownloadAndPlay(song)
    }

    open fun startProgressiveVideoDownloadAndPlay(song: Song) {
        playbackJob?.cancel()
        videoJob?.cancel()
        recoveryController.cancelRecovery()
        val generation = ++playbackGeneration
        desiredPlaybackState = DesiredPlaybackState.PLAYING
        _playbackStatus.value = PlaybackStatus.RESOLVING
        _isLoading.value = true

        videoJob = scope.launch(ioDispatcher) {
            val targetVideoId = preloadController.resolvedVideoIdMap[song.id] ?: song.id
            if (generation != playbackGeneration) return@launch

            val videoResult = resolver.resolveVideoStream(targetVideoId, _currentVideoQuality.value)
            if (generation != playbackGeneration) return@launch

            withContext(mainDispatcher) {
                if (generation != playbackGeneration) return@withContext

                if (videoResult != null && videoResult.url.isNotBlank()) {
                    if (videoResult.audioUrl != null && videoResult.audioUrl.isNotBlank()) {
                        engine.setMergingMediaSource(
                            videoUri = videoResult.url,
                            audioUri = videoResult.audioUrl,
                            song = song,
                            headers = videoResult.headers
                        )
                    } else {
                        engine.setMediaSource(
                            uri = videoResult.url,
                            song = song,
                            headers = videoResult.headers,
                            isFile = videoResult.url.startsWith("/")
                        )
                    }
                    engine.prepare()
                    val targetPos = pendingSeekPosition ?: _positionMs.value
                    if (targetPos > 0L) engine.seekTo(targetPos)
                    pendingSeekPosition = null

                    if (desiredPlaybackState == DesiredPlaybackState.PLAYING) {
                        engine.play()
                        _isPlaying.value = true
                        _playbackStatus.value = PlaybackStatus.PLAYING
                    } else {
                        engine.pause()
                        _isPlaying.value = false
                        _playbackStatus.value = PlaybackStatus.PAUSED
                    }
                    _isLoading.value = false
                } else {
                    isVideoModeActive = false
                    _isLoading.value = false
                    executePlayback(song, _positionMs.value)
                }
            }
        }
    }

    open fun executePlayback(song: Song, initialPosMs: Long = 0L) {
        if (_playbackStatus.value == PlaybackStatus.RESOLVING && queueController.currentSongValue?.id == song.id && desiredPlaybackState == DesiredPlaybackState.PLAYING) {
            return
        }

        playbackJob?.cancel()
        videoJob?.cancel()
        recoveryController.cancelRecovery()
        val generation = ++playbackGeneration
        desiredPlaybackState = DesiredPlaybackState.PLAYING
        _playbackStatus.value = PlaybackStatus.RESOLVING
        _isLoading.value = true
        eunoiaTrackChangeListener?.invoke(song)

        hasTriggered70Percent = false
        fetchLyricsForCurrentSong()
        _positionMs.value = initialPosMs.coerceAtLeast(0L)

        engine.stop()
        engine.clearMediaItems()

        if (isVideoModeActive) {
            startProgressiveVideoDownloadAndPlay(song)
            return
        }

        playbackJob = scope.launch(ioDispatcher) {
            try {
                val targetVideoId = preloadController.resolvedVideoIdMap[song.id] ?: song.id
                if (generation != playbackGeneration) return@launch

                val result = preloadController.getValidCachedStream(targetVideoId)
                    ?: resolver.resolveAudioStream(targetVideoId, song.title, song.author)

                if (generation != playbackGeneration) return@launch

                if (result != null && result.url.isNotBlank()) {
                    preloadController.cacheStreamResult(song.id, targetVideoId, result)
                }

                withContext(mainDispatcher) {
                    if (generation != playbackGeneration) return@withContext

                    if (result != null && result.url.isNotBlank()) {
                        val streamUrl = result.url
                        val headers = result.headers
                        val isLocal = streamUrl.startsWith("/") || streamUrl.startsWith("file://")

                        engine.setMediaSource(streamUrl, song, headers, isLocal)
                        engine.prepare()

                        val seekTarget = pendingSeekPosition ?: initialPosMs
                        if (seekTarget > 0L) {
                            engine.seekTo(seekTarget)
                        }
                        pendingSeekPosition = null

                        if (desiredPlaybackState == DesiredPlaybackState.PLAYING) {
                            engine.play()
                            _isPlaying.value = true
                            _playbackStatus.value = PlaybackStatus.PLAYING
                        } else {
                            engine.pause()
                            _isPlaying.value = false
                            _playbackStatus.value = PlaybackStatus.PAUSED
                        }
                        _isLoading.value = false
                        maybePrefetchNextTrack()
                    } else {
                        _isLoading.value = false
                        _playbackStatus.value = PlaybackStatus.FAILED
                    }
                }
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                withContext(mainDispatcher) {
                    if (generation != playbackGeneration) return@withContext
                    _isLoading.value = false
                    _playbackStatus.value = PlaybackStatus.FAILED
                }
            }
        }
    }

    open fun play() {
        desiredPlaybackState = DesiredPlaybackState.PLAYING
        scope.launch(mainDispatcher) {
            commandChannel.send(PlaybackAction.Resume)
        }
    }

    open fun pause() {
        desiredPlaybackState = DesiredPlaybackState.PAUSED
        scope.launch(mainDispatcher) {
            commandChannel.send(PlaybackAction.Pause)
        }
    }

    open fun stop() {
        desiredPlaybackState = DesiredPlaybackState.STOPPED
        scope.launch(mainDispatcher) {
            commandChannel.send(PlaybackAction.Stop)
        }
    }

    open fun togglePlayPause() {
        if (engine.isPlaying || _isLoading.value) {
            pause()
        } else {
            play()
        }
    }

    open fun playNext() {
        scope.launch(mainDispatcher) {
            commandChannel.send(PlaybackAction.Next)
        }
    }

    open fun playPrevious() {
        scope.launch(mainDispatcher) {
            commandChannel.send(PlaybackAction.Previous)
        }
    }

    open fun seekTo(positionMs: Long) {
        scope.launch(mainDispatcher) {
            commandChannel.send(PlaybackAction.Seek(positionMs))
        }
    }

    open fun setPlaybackSpeed(speed: Float) {
        val safeSpeed = speed.coerceIn(0.5f, 2.0f)
        engine.setPlaybackSpeed(safeSpeed)
    }

    fun startProgressTicker() {
        progressJob?.cancel()
        if (!progressTickerEnabled) return
        progressJob = scope.launch(mainDispatcher) {
            while (isActive && engine.isPlaying) {
                _positionMs.value = engine.currentPosition.coerceAtLeast(0L)
                val dur = engine.duration
                if (dur > 0L) {
                    _durationMs.value = dur
                }

                if (_durationMs.value > 0L && (_positionMs.value.toDouble() / _durationMs.value.toDouble()) >= 0.70) {
                    if (!hasTriggered70Percent) {
                        hasTriggered70Percent = true
                        warmSmartQueue()
                        prefetchNextStream()
                    }
                }
                delay(300)
            }
        }
    }

    fun stopProgressTicker() {
        progressJob?.cancel()
        progressJob = null
        if (!engine.isPlaying) {
            _positionMs.value = engine.currentPosition.coerceAtLeast(0L)
        }
    }

    /**
     * Unified state machine decision execution.
     */
    fun dispatchPlaybackDecision(decision: PlaybackDecision) {
        when (decision) {
            is PlaybackDecision.Play -> {
                executePlayback(decision.song, decision.initialPosMs)
            }
            is PlaybackDecision.ReplayCurrent -> {
                pendingSeekPosition = 0L
                _positionMs.value = 0L
                executePlayback(decision.song, 0L)
            }
            is PlaybackDecision.EndOfQueue -> {
                _isPlaying.value = false
                _playbackStatus.value = PlaybackStatus.ENDED
            }
            is PlaybackDecision.Stop -> {
                desiredPlaybackState = DesiredPlaybackState.STOPPED
                playbackJob?.cancel()
                videoJob?.cancel()
                recoveryController.cancelRecovery()
                savePositionCheckpoint()
                ++playbackGeneration
                engine.stop()
                _isPlaying.value = false
                _isLoading.value = false
                _playbackStatus.value = PlaybackStatus.IDLE
            }
        }
    }

    /**
     * Transactional and generation-safe track ended handler delegating to the serialized command channel.
     */
    fun handleTrackEnded() {
        stopProgressTicker()
        if (_playbackStatus.value == PlaybackStatus.RESOLVING) return
        val capturedPlaybackGen = playbackGeneration
        val capturedSongId = queueController.currentSongValue?.id

        scope.launch(mainDispatcher) {
            commandChannel.send(PlaybackAction.TrackEnded(capturedPlaybackGen, capturedSongId))
        }
    }
}
