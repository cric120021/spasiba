package app.spasiba.nativeapp2.player

import app.spasiba.nativeapp2.data.api.StreamingResult
import app.spasiba.nativeapp2.data.model.Song
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Controller managing Smart Queue replenishing, track prefetching, and pre-resolved stream caching.
 */
class PreloadController(
    private val resolver: StreamResolver,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val mainDispatcher: CoroutineDispatcher = Dispatchers.Main
) {
    companion object {
        const val MAX_CACHE_ENTRIES = 60
        const val STREAM_CACHE_TTL_MS = 3 * 3600 * 1000L
        const val VIDEO_ID_CACHE_TTL_MS = 24 * 3600 * 1000L
    }

    // In-memory bounded LRU / TTL caches
    val preResolvedStreamMap = LruMemoryCache<String, CachedStream>(MAX_CACHE_ENTRIES, STREAM_CACHE_TTL_MS)
    val resolvedVideoIdMap = LruMemoryCache<String, String>(MAX_CACHE_ENTRIES, VIDEO_ID_CACHE_TTL_MS)

    var prefetchedVideoId: String? = null
    var lastWarmedSongId: String? = null

    var prefetchJob: Job? = null
    var queueWarmingJob: Job? = null
    var radioQueueJob: Job? = null

    fun cancelAll() {
        prefetchJob?.cancel()
        queueWarmingJob?.cancel()
        radioQueueJob?.cancel()
        prefetchJob = null
        queueWarmingJob = null
        radioQueueJob = null
    }

    fun clear() {
        cancelAll()
        prefetchedVideoId = null
        lastWarmedSongId = null
        preResolvedStreamMap.clear()
        resolvedVideoIdMap.clear()
    }

    fun getValidCachedStream(targetId: String): StreamingResult? {
        val cached = preResolvedStreamMap[targetId] ?: return null
        val age = System.currentTimeMillis() - cached.timestampMs
        if (age < STREAM_CACHE_TTL_MS && cached.result.url.isNotBlank()) {
            return cached.result
        }
        preResolvedStreamMap.remove(targetId)
        return null
    }

    fun cacheStreamResult(songId: String, videoId: String?, result: StreamingResult) {
        val entry = CachedStream(result, System.currentTimeMillis())
        preResolvedStreamMap[songId] = entry
        if (videoId != null && videoId != songId) {
            preResolvedStreamMap[videoId] = entry
        }
    }

    fun warmSmartQueue(
        currentTrack: Song?,
        currentQueue: List<Song>,
        currentIndex: Int,
        queueGeneration: Long,
        playbackGeneration: Long,
        isStateValid: (Long, Long, String?) -> Boolean,
        onNewTracksAppended: (List<Song>, String) -> Unit
    ) {
        if (currentTrack == null) return
        if ((currentQueue.size - currentIndex) >= 6) return
        if (lastWarmedSongId == currentTrack.id) return
        if (queueWarmingJob?.isActive == true) return

        queueWarmingJob = scope.launch(ioDispatcher) {
            try {
                val queries = listOf("${currentTrack.title} ${currentTrack.author} playlist", "${currentTrack.author} radio")
                val fetchedSongs = queries.flatMap { q -> resolver.searchSongs(q) }

                if (fetchedSongs.isNotEmpty()) {
                    withContext(mainDispatcher) {
                        if (!isStateValid(queueGeneration, playbackGeneration, currentTrack.id)) return@withContext

                        val deduplicated = fetchedSongs.filter { cand -> !currentQueue.any { it.id == cand.id } }
                        if (deduplicated.isNotEmpty()) {
                            // Commit marker ONLY upon successful merge!
                            lastWarmedSongId = currentTrack.id
                            onNewTracksAppended(deduplicated, currentTrack.id)
                        }
                    }
                }
            } catch (e: Exception) {
                if (e is CancellationException) throw e
            } finally {
                queueWarmingJob = null
            }
        }
    }

    fun prefetchNextStream(
        nextTrack: Song?,
        queueGeneration: Long,
        playbackGeneration: Long,
        isStateValid: (Long, Long) -> Boolean
    ) {
        if (nextTrack == null) return
        if (prefetchedVideoId == nextTrack.id) return
        if (prefetchJob?.isActive == true) return

        prefetchJob = scope.launch(ioDispatcher) {
            try {
                val targetId = resolvedVideoIdMap[nextTrack.id] ?: nextTrack.id
                val streamResult = resolver.resolveAudioStream(targetId, nextTrack.title, nextTrack.author)

                if (streamResult != null && streamResult.url.isNotBlank()) {
                    withContext(mainDispatcher) {
                        if (isStateValid(queueGeneration, playbackGeneration)) {
                            val entry = CachedStream(streamResult, System.currentTimeMillis())
                            preResolvedStreamMap[nextTrack.id] = entry
                            preResolvedStreamMap[targetId] = entry
                            // Commit marker ONLY upon successful resolution!
                            prefetchedVideoId = nextTrack.id
                        }
                    }
                }
            } catch (e: Exception) {
                if (e is CancellationException) throw e
            } finally {
                prefetchJob = null
            }
        }
    }

    fun replenishRadioQueue(
        currentTrack: Song,
        queueGeneration: Long,
        playbackGeneration: Long,
        isStateValid: (Long, Long, String?) -> Boolean,
        onRadioTracksReceived: (List<Song>) -> Unit
    ) {
        radioQueueJob?.cancel()
        radioQueueJob = scope.launch(ioDispatcher) {
            try {
                val candidateTracks = resolver.generateRadioQueue(currentTrack)
                if (candidateTracks.isNotEmpty()) {
                    withContext(mainDispatcher) {
                        if (!isStateValid(queueGeneration, playbackGeneration, currentTrack.id)) return@withContext
                        onRadioTracksReceived(candidateTracks)
                    }
                }
            } catch (e: Exception) {
                if (e is CancellationException) throw e
            } finally {
                radioQueueJob = null
            }
        }
    }
}
