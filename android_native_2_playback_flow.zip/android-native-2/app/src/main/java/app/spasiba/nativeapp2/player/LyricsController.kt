package app.spasiba.nativeapp2.player

import app.spasiba.nativeapp2.data.model.Song
import app.spasiba.nativeapp2.data.repository.LyricLine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Controller managing unified synced & plain lyrics, caching, and non-blocking loading states.
 */
class LyricsController(
    private val resolver: StreamResolver,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val mainDispatcher: CoroutineDispatcher = Dispatchers.Main
) {
    val lyricsMemoryCache = LruMemoryCache<String, List<LyricLine>>(60, 12 * 3600 * 1000L)

    private val _currentLyrics = MutableStateFlow<String?>(null)
    val currentLyrics: StateFlow<String?> = _currentLyrics.asStateFlow()

    private val _syncedLyrics = MutableStateFlow<List<LyricLine>>(emptyList())
    val syncedLyrics: StateFlow<List<LyricLine>> = _syncedLyrics.asStateFlow()

    private val _isLyricsLoading = MutableStateFlow(false)
    val isLyricsLoading: StateFlow<Boolean> = _isLyricsLoading.asStateFlow()

    var lastLoadedLyricsSongId: String? = null
    var lyricsJob: Job? = null

    fun cancelLyrics() {
        lyricsJob?.cancel()
        lyricsJob = null
        _isLyricsLoading.value = false
    }

    fun clear() {
        cancelLyrics()
        lastLoadedLyricsSongId = null
        _currentLyrics.value = null
        _syncedLyrics.value = emptyList()
        _isLyricsLoading.value = false
    }

    fun fetchLyricsForSong(
        song: Song?,
        generation: Long,
        isGenerationValid: (Long) -> Boolean,
        isSongActive: (String) -> Boolean,
        force: Boolean = false
    ) {
        if (song == null) {
            clear()
            return
        }

        val targetSongId = song.id
        if (!force && lastLoadedLyricsSongId == targetSongId && _syncedLyrics.value.isNotEmpty()) {
            _isLyricsLoading.value = false
            return
        }

        lyricsMemoryCache[targetSongId]?.let { cached ->
            lastLoadedLyricsSongId = targetSongId
            _syncedLyrics.value = cached
            _currentLyrics.value = cached.joinToString("\n") { it.text }
            _isLyricsLoading.value = false
            return
        }

        lyricsJob?.cancel()
        _isLyricsLoading.value = true

        lyricsJob = scope.launch(ioDispatcher) {
            try {
                val lines = resolver.fetchUnifiedLyrics(song.id, song.title, song.author, song.durationSeconds)
                if (lines.isNotEmpty()) {
                    lyricsMemoryCache[targetSongId] = lines
                }
                withContext(mainDispatcher) {
                    if (isGenerationValid(generation) && isSongActive(targetSongId)) {
                        lastLoadedLyricsSongId = targetSongId
                        _syncedLyrics.value = lines
                        _currentLyrics.value = if (lines.isNotEmpty()) lines.joinToString("\n") { it.text } else null
                    }
                }
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                // Non-fatal error; lyrics remain empty
            } finally {
                withContext(mainDispatcher) {
                    if (isGenerationValid(generation) && isSongActive(targetSongId)) {
                        _isLyricsLoading.value = false
                    }
                }
            }
        }
    }
}
