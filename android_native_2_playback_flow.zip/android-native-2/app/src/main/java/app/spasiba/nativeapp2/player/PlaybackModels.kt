package app.spasiba.nativeapp2.player

import app.spasiba.nativeapp2.data.api.StreamingResult
import app.spasiba.nativeapp2.data.model.Song

enum class PlaybackStatus {
    IDLE,
    BUFFERING,
    RESOLVING,
    PLAYING,
    PAUSED,
    ENDED,
    RECOVERING,
    FAILED
}

enum class RepeatState {
    OFF,
    ALL,
    ONE
}

enum class DesiredPlaybackState {
    PLAYING,
    PAUSED,
    STOPPED
}

data class CachedStream(
    val result: StreamingResult,
    val timestampMs: Long
)

/**
 * Authoritative ShuffleSession maintaining deterministic playback order mapping
 * without destructively modifying the underlying canonical playlist.
 */
data class ShuffleSession(
    val sessionId: String = java.util.UUID.randomUUID().toString(),
    val sessionSeed: Long = System.currentTimeMillis(),
    val originalCanonicalIds: List<String> = emptyList(),
    val playbackOrder: List<String> = emptyList(),
    val temporaryPlayNextIds: List<String> = emptyList()
)

/**
 * Pure Structural Queue State. Position checkpoints are kept decoupled to avoid lock contention.
 */
data class PlaybackQueueState(
    val songs: List<Song> = emptyList(),
    val currentIndex: Int = -1,
    val currentSong: Song? = null,
    val canonicalQueue: List<Song> = emptyList(),
    val queueGeneration: Long = 0L,
    val isShuffleEnabled: Boolean = false,
    val repeatState: RepeatState = RepeatState.OFF,
    val shuffleSession: ShuffleSession? = null
)

/**
 * Reasons for querying the unified next-track decision engine.
 */
enum class NextTrackReason {
    TRACK_ENDED,
    USER_NEXT,
    USER_PREVIOUS,
    REMOVE_CURRENT,
    AUTOPLAY,
    RADIO_CONTINUATION
}

/**
 * Output of the unified Next-Decision Engine.
 */
sealed class PlaybackDecision {
    data class Play(val song: Song, val initialPosMs: Long = 0L) : PlaybackDecision()
    data class ReplayCurrent(val song: Song) : PlaybackDecision()
    data object Stop : PlaybackDecision()
    data object EndOfQueue : PlaybackDecision()
}

/**
 * Serialized Playback Actions processed sequentially by PlaybackCoordinator command channel.
 */
sealed class PlaybackAction {
    data class Play(val song: Song, val initialPosMs: Long = 0L) : PlaybackAction()
    data object Pause : PlaybackAction()
    data object Resume : PlaybackAction()
    data object Stop : PlaybackAction()
    data class Seek(val positionMs: Long) : PlaybackAction()
    data object Next : PlaybackAction()
    data object Previous : PlaybackAction()
    data class TrackEnded(val generation: Long, val songId: String?) : PlaybackAction()
    data class TrackError(val generation: Long, val errorCode: Int, val message: String?) : PlaybackAction()
    data class SelectItem(val songId: String) : PlaybackAction()
}
