package app.spasiba.nativeapp2.player

import app.spasiba.nativeapp2.data.model.Song

/**
 * PlayerEngine abstraction interface for Media3 ExoPlayer or deterministic headless fakes.
 */
interface PlayerEngine {
    companion object {
        const val STATE_IDLE = 1
        const val STATE_BUFFERING = 2
        const val STATE_READY = 3
        const val STATE_ENDED = 4
    }

    interface Listener {
        fun onPlaybackStateChanged(playbackState: Int)
        fun onIsPlayingChanged(isPlaying: Boolean)
        fun onVideoSizeChanged(width: Int, height: Int)
        fun onPlayerError(errorCode: Int, message: String?)
    }

    val isPlaying: Boolean
    val currentPosition: Long
    val duration: Long
    val playbackState: Int

    fun play()
    fun pause()
    fun stop()
    fun seekTo(positionMs: Long)
    fun setMediaSource(uri: String, song: Song? = null, headers: Map<String, String>? = null, isFile: Boolean = false)
    fun setMergingMediaSource(videoUri: String, audioUri: String, song: Song? = null, headers: Map<String, String>? = null)
    fun prepare()
    fun clearMediaItems()
    fun setPlaybackSpeed(speed: Float)
    fun setListener(listener: Listener)
}
