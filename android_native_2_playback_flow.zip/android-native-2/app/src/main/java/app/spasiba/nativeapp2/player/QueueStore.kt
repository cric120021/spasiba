package app.spasiba.nativeapp2.player

import app.spasiba.nativeapp2.data.cache.QueueSnapshot
import app.spasiba.nativeapp2.data.model.Song

/**
 * Snapshot cache abstraction for async queue persistence.
 */
interface QueueStore {
    suspend fun saveSnapshot(songs: List<Song>, currentIndex: Int, positionMs: Long)
    suspend fun restoreSnapshot(): QueueSnapshot?
}
