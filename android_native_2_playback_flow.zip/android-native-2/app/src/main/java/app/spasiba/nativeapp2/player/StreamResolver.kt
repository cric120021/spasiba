package app.spasiba.nativeapp2.player

import app.spasiba.nativeapp2.data.api.StreamingResult
import app.spasiba.nativeapp2.data.model.Song
import app.spasiba.nativeapp2.data.repository.LyricLine

/**
 * Resolver abstraction for stream URLs, unified lyrics, and radio queue replenishment.
 */
interface StreamResolver {
    suspend fun resolveAudioStream(songId: String, title: String, author: String): StreamingResult?
    suspend fun resolveVideoStream(videoId: String, quality: String): StreamingResult?
    suspend fun fetchUnifiedLyrics(songId: String, title: String, author: String, durationSec: Int): List<LyricLine>
    suspend fun generateRadioQueue(seedSong: Song): List<Song>
    suspend fun searchSongs(query: String): List<Song>
}
