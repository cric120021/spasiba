package app.spasiba.nativeapp2.data.cache

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import app.spasiba.nativeapp2.data.model.Song
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class QueueSnapshot(
    val songs: List<Song>,
    val currentIndex: Int,
    val positionMs: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val schemaVersion: Int = 1
)

class QueueSnapshotCache(context: Context) {
    private val TAG = "QueueSnapshotCache"
    private val prefs: SharedPreferences = context.getSharedPreferences("spasiba_queue_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        private const val KEY_QUEUE = "key_queue_snapshot"
        private const val CURRENT_SCHEMA_VERSION = 1
        private const val THREE_DAYS_MS = 3 * 24 * 60 * 60 * 1000L
    }

    suspend fun saveSnapshot(songs: List<Song>, currentIndex: Int, positionMs: Long = 0L) = withContext(Dispatchers.IO) {
        if (songs.isEmpty()) {
            runCatching {
                prefs.edit().remove(KEY_QUEUE).apply()
            }
            return@withContext
        }
        runCatching {
            val sanitizedSongs = songs.take(80).map { it.copy(streamUrl = null) }
            val snapshot = QueueSnapshot(
                songs = sanitizedSongs,
                currentIndex = currentIndex.coerceIn(0, sanitizedSongs.lastIndex.coerceAtLeast(0)),
                positionMs = positionMs.coerceAtLeast(0L),
                timestamp = System.currentTimeMillis(),
                schemaVersion = CURRENT_SCHEMA_VERSION
            )
            val json = gson.toJson(snapshot)
            prefs.edit().putString(KEY_QUEUE, json).apply()
        }.onFailure { e ->
            Log.e(TAG, "Failed to persist queue snapshot: ${e.message}")
        }
    }

    suspend fun restoreSnapshot(): QueueSnapshot? = withContext(Dispatchers.IO) {
        val json = prefs.getString(KEY_QUEUE, null) ?: return@withContext null
        return@withContext try {
            val type = object : TypeToken<QueueSnapshot>() {}.type
            val snapshot: QueueSnapshot = gson.fromJson(json, type)
            if (snapshot.schemaVersion != CURRENT_SCHEMA_VERSION) {
                Log.w(TAG, "Queue snapshot schema mismatch (${snapshot.schemaVersion} vs $CURRENT_SCHEMA_VERSION). Discarding.")
                null
            } else if (System.currentTimeMillis() - snapshot.timestamp > THREE_DAYS_MS) {
                null
            } else {
                val sanitizedSongs = snapshot.songs.take(80).map { it.copy(streamUrl = null) }
                snapshot.copy(songs = sanitizedSongs)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Corrupt queue snapshot detected, clearing cache: ${e.message}")
            prefs.edit().remove(KEY_QUEUE).apply()
            null
        }
    }
}
