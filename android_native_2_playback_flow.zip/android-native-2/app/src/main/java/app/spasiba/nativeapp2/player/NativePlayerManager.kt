package app.spasiba.nativeapp2.player

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.extractor.DefaultExtractorsFactory
import app.spasiba.nativeapp2.data.api.StreamingResult
import app.spasiba.nativeapp2.data.api.YouTubeMusicApi
import app.spasiba.nativeapp2.data.cache.QueueSnapshot
import app.spasiba.nativeapp2.data.cache.QueueSnapshotCache
import app.spasiba.nativeapp2.data.cache.SpasibaAudioCacheManager
import app.spasiba.nativeapp2.data.download.SpasibaDownloadManager
import app.spasiba.nativeapp2.data.engine.QuickPicksEngine
import app.spasiba.nativeapp2.data.model.Song
import app.spasiba.nativeapp2.data.repository.LyricLine
import app.spasiba.nativeapp2.data.repository.MusicRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class NativePlayerManager(private val context: Context) {
    private val TAG = "NativePlayerManager"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val repository = MusicRepository(context)
    private val queueCache = QueueSnapshotCache(context)
    private val audioCacheManager = SpasibaAudioCacheManager(context)
    private val downloadManager = SpasibaDownloadManager.getInstance(context)

    private val _likedSongIds = MutableStateFlow<Set<String>>(emptySet())
    val likedSongIds: StateFlow<Set<String>> = _likedSongIds.asStateFlow()

    private fun ensureMediaServiceStarted() {
        runCatching {
            val serviceIntent = Intent(context, app.spasiba.nativeapp2.service.SpasibaMediaService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ContextCompat.startForegroundService(context, serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }
    }

    private fun createHttpDataSourceFactory(headers: Map<String, String>? = null): DefaultHttpDataSource.Factory {
        val factory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(8000)
            .setReadTimeoutMs(8000)
        if (headers != null && headers.isNotEmpty()) {
            val safeHeaders = headers.toMutableMap().apply {
                putIfAbsent("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
            }
            factory.setDefaultRequestProperties(safeHeaders)
        }
        return factory
    }

    val exoPlayer: ExoPlayer by lazy {
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                1000,  // Min buffer: 1.0s
                30000, // Max buffer: 30s
                200,   // Buffer for playback: 200ms
                500    // Buffer after rebuffer: 500ms
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        ExoPlayer.Builder(context)
            .setLoadControl(loadControl)
            .build().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                        .build(),
                    true
                )
                setHandleAudioBecomingNoisy(true)
                setWakeMode(C.WAKE_MODE_NETWORK)
            }
    }

    private var engineListener: PlayerEngine.Listener? = null

    private val playerEngine: PlayerEngine = object : PlayerEngine {
        override val isPlaying: Boolean get() = exoPlayer.isPlaying
        override val currentPosition: Long get() = exoPlayer.currentPosition.coerceAtLeast(0L)
        override val duration: Long get() {
            val d = exoPlayer.duration
            return if (d != C.TIME_UNSET && d > 0L) d else 0L
        }
        override val playbackState: Int get() = when (exoPlayer.playbackState) {
            Player.STATE_IDLE -> PlayerEngine.STATE_IDLE
            Player.STATE_BUFFERING -> PlayerEngine.STATE_BUFFERING
            Player.STATE_READY -> PlayerEngine.STATE_READY
            Player.STATE_ENDED -> PlayerEngine.STATE_ENDED
            else -> PlayerEngine.STATE_IDLE
        }

        override fun play() {
            ensureMediaServiceStarted()
            exoPlayer.playWhenReady = true
            exoPlayer.play()
        }

        override fun pause() {
            exoPlayer.playWhenReady = false
            exoPlayer.pause()
        }

        override fun stop() {
            exoPlayer.stop()
        }

        override fun seekTo(positionMs: Long) {
            exoPlayer.seekTo(positionMs.coerceAtLeast(0L))
        }

        override fun setMediaSource(uri: String, song: Song?, headers: Map<String, String>?, isFile: Boolean) {
            val mediaMetadata = MediaMetadata.Builder()
                .setTitle(song?.title ?: "Music")
                .setArtist(song?.author ?: "Unknown")
                .setArtworkUri(if (song?.thumbnail != null) Uri.parse(song.thumbnail) else null)
                .build()

            val mediaItem = MediaItem.Builder()
                .setUri(if (isFile) Uri.fromFile(File(uri)) else Uri.parse(uri))
                .setMediaId(song?.id ?: "track")
                .setMediaMetadata(mediaMetadata)
                .build()

            if (isFile) {
                exoPlayer.setMediaItem(mediaItem)
            } else {
                val dataSourceFactory = createHttpDataSourceFactory(headers)
                val mediaSourceFactory = DefaultMediaSourceFactory(context, DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true))
                    .setDataSourceFactory(dataSourceFactory)
                val mediaSource = mediaSourceFactory.createMediaSource(mediaItem)
                exoPlayer.setMediaSource(mediaSource)
            }
        }

        override fun setMergingMediaSource(videoUri: String, audioUri: String, song: Song?, headers: Map<String, String>?) {
            val mediaMetadata = MediaMetadata.Builder()
                .setTitle(song?.title ?: "Music Video")
                .setArtist(song?.author ?: "Unknown")
                .setArtworkUri(if (song?.thumbnail != null) Uri.parse(song.thumbnail) else null)
                .build()

            val videoMediaItem = MediaItem.Builder()
                .setUri(Uri.parse(videoUri))
                .setMediaId(song?.id ?: "video")
                .setMediaMetadata(mediaMetadata)
                .build()

            val audioMediaItem = MediaItem.Builder()
                .setUri(Uri.parse(audioUri))
                .setMediaId("${song?.id ?: "audio"}_audio")
                .build()

            val dataSourceFactory = createHttpDataSourceFactory(headers)
            val mediaSourceFactory = DefaultMediaSourceFactory(context, DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true))
                .setDataSourceFactory(dataSourceFactory)

            val videoSource = mediaSourceFactory.createMediaSource(videoMediaItem)
            val audioSource = mediaSourceFactory.createMediaSource(audioMediaItem)
            exoPlayer.setMediaSource(MergingMediaSource(videoSource, audioSource))
        }

        override fun prepare() {
            exoPlayer.prepare()
        }

        override fun clearMediaItems() {
            exoPlayer.clearMediaItems()
        }

        override fun setPlaybackSpeed(speed: Float) {
            exoPlayer.setPlaybackSpeed(speed)
        }

        override fun setListener(listener: PlayerEngine.Listener) {
            engineListener = listener
        }
    }

    private val streamResolver: StreamResolver = object : StreamResolver {
        override suspend fun resolveAudioStream(songId: String, title: String, author: String): StreamingResult? {
            val localFile = downloadManager.getDownloadedFile(songId)
                ?: audioCacheManager.findCachedAudioFile(songId)
                ?: File(context.cacheDir, "spasiba_audio/$songId.m4a").takeIf { it.exists() && it.length() > 0 }
                ?: File(context.cacheDir, "spasiba_video/$songId.mp4").takeIf { it.exists() && it.length() > 0 }

            if (localFile != null && localFile.length() > 0) {
                return StreamingResult(
                    url = localFile.absolutePath,
                    audioUrl = null,
                    headers = emptyMap()
                )
            }

            return repository.resolveStreamResult(songId)
                ?: YouTubeMusicApi.resolveStreamResult(context, songId)
        }

        override suspend fun resolveVideoStream(videoId: String, quality: String): StreamingResult? {
            return YouTubeMusicApi.resolveVideoStreamResult(context, videoId, quality)
        }

        override suspend fun fetchUnifiedLyrics(songId: String, title: String, author: String, durationSec: Int): List<LyricLine> {
            return YouTubeMusicApi.fetchUnifiedLyrics(songId, title, author, durationSec)
        }

        override suspend fun generateRadioQueue(seedSong: Song): List<Song> {
            return QuickPicksEngine.generateRadioQueue(seedSong)
        }

        override suspend fun searchSongs(query: String): List<Song> {
            return YouTubeMusicApi.searchSongs(query)
        }
    }

    private val queueStore: QueueStore = object : QueueStore {
        override suspend fun saveSnapshot(songs: List<Song>, currentIndex: Int, positionMs: Long) {
            queueCache.saveSnapshot(songs, currentIndex, positionMs)
        }

        override suspend fun restoreSnapshot(): QueueSnapshot? {
            return queueCache.restoreSnapshot()
        }
    }

    val coordinator: PlaybackCoordinator = PlaybackCoordinator(
        engine = playerEngine,
        resolver = streamResolver,
        queueStore = queueStore,
        scope = scope
    )

    private val playerListener: Player.Listener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            val engineState = when (playbackState) {
                Player.STATE_IDLE -> PlayerEngine.STATE_IDLE
                Player.STATE_BUFFERING -> PlayerEngine.STATE_BUFFERING
                Player.STATE_READY -> PlayerEngine.STATE_READY
                Player.STATE_ENDED -> PlayerEngine.STATE_ENDED
                else -> PlayerEngine.STATE_IDLE
            }
            engineListener?.onPlaybackStateChanged(engineState)
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            engineListener?.onIsPlayingChanged(isPlaying)
        }

        override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
            engineListener?.onVideoSizeChanged(videoSize.width, videoSize.height)
        }

        override fun onPlayerError(error: PlaybackException) {
            engineListener?.onPlayerError(error.errorCode, error.message)
        }
    }

    init {
        exoPlayer.addListener(playerListener)
        observeLikedSongs()
        restoreQueue()
    }

    private fun observeLikedSongs() {
        scope.launch {
            repository.likedSongs.collectLatest { list ->
                _likedSongIds.value = list.map { it.id }.toSet()
            }
        }
    }

    private fun restoreQueue() {
        scope.launch(Dispatchers.IO) {
            val snapshot = queueStore.restoreSnapshot()
            withContext(Dispatchers.Main) {
                if (snapshot != null && snapshot.songs.isNotEmpty() && snapshot.currentIndex in snapshot.songs.indices) {
                    coordinator.queueController.mutateQueue { state ->
                        state.copy(
                            songs = snapshot.songs,
                            currentIndex = snapshot.currentIndex,
                            currentSong = snapshot.songs[snapshot.currentIndex],
                            canonicalQueue = snapshot.songs
                        )
                    }
                    if (snapshot.positionMs > 0L) {
                        coordinator._positionMs.value = snapshot.positionMs
                    }
                    coordinator.maybePrefetchNextTrack()
                } else {
                    val fallbacks = YouTubeMusicApi.getFallbackTracks()
                    if (fallbacks.isNotEmpty()) {
                        coordinator.queueController.mutateQueue { state ->
                            state.copy(
                                songs = fallbacks,
                                currentIndex = -1,
                                currentSong = null,
                                canonicalQueue = fallbacks
                            )
                        }
                    }
                }
            }
        }
    }

    // Explicitly typed StateFlow properties
    val queueState: StateFlow<PlaybackQueueState> get() = coordinator.queueState
    val currentSong: StateFlow<Song?> get() = coordinator.currentSong
    val queue: StateFlow<List<Song>> get() = coordinator.queue
    val currentIndex: StateFlow<Int> get() = coordinator.currentIndex
    val playbackStatus: StateFlow<PlaybackStatus> get() = coordinator.playbackStatus
    val queueSourceLabel: StateFlow<String> get() = coordinator.queueSourceLabel
    val isPlaying: StateFlow<Boolean> get() = coordinator.isPlaying
    val isLoading: StateFlow<Boolean> get() = coordinator.isLoading
    val positionMs: StateFlow<Long> get() = coordinator.positionMs
    val durationMs: StateFlow<Long> get() = coordinator.durationMs
    val repeatState: StateFlow<RepeatState> get() = coordinator.repeatState
    val isShuffleEnabled: StateFlow<Boolean> get() = coordinator.isShuffleEnabled
    val currentLyrics: StateFlow<String?> get() = coordinator.currentLyrics
    val syncedLyrics: StateFlow<List<LyricLine>> get() = coordinator.syncedLyrics
    val isLyricsLoading: StateFlow<Boolean> get() = coordinator.isLyricsLoading
    val videoAspectRatio: StateFlow<Float> get() = coordinator.videoAspectRatio
    val videoQuality: StateFlow<String> get() = coordinator.videoQuality
    val availableVideoQualities: StateFlow<List<String>> get() = coordinator.availableVideoQualities

    var isVideoModeActive: Boolean
        get() = coordinator.isVideoModeActive
        set(value) { coordinator.isVideoModeActive = value }

    var eunoiaTrackChangeListener: ((Song) -> Unit)?
        get() = coordinator.eunoiaTrackChangeListener
        set(value) { coordinator.eunoiaTrackChangeListener = value }

    var eunoiaPlaybackActionListener: ((action: String, extraPayload: org.json.JSONObject?) -> Unit)?
        get() = coordinator.eunoiaPlaybackActionListener
        set(value) { coordinator.eunoiaPlaybackActionListener = value }

    fun setQueue(tracks: List<Song>, activeSongId: String?, sourceLabel: String = "Spasiba Radio") = coordinator.setQueue(tracks, activeSongId, sourceLabel)
    fun playQueue(songs: List<Song>, startIndex: Int = 0, sourceLabel: String = "Spasiba Radio") = coordinator.playQueue(songs, startIndex, sourceLabel)
    fun playSingleSongWithRadio(clickedSong: Song, sourceLabel: String = "Spasiba Radio") = coordinator.playSingleSongWithRadio(clickedSong, sourceLabel)
    fun playStandaloneItem(song: Song) = coordinator.playStandaloneItem(song)
    fun playQueueItem(songId: String) = coordinator.playQueueItem(songId)
    fun playSong(song: Song, initialPosMs: Long = 0L) = coordinator.playSong(song, initialPosMs)
    fun addToQueue(song: Song) = coordinator.addToQueue(song)
    fun playNextInQueue(song: Song) = coordinator.playNextInQueue(song)
    fun removeFromQueue(index: Int) = coordinator.removeFromQueue(index)
    fun moveInQueue(fromIndex: Int, toIndex: Int) = coordinator.moveInQueue(fromIndex, toIndex)
    fun clearQueue() = coordinator.clearQueue()
    fun toggleShuffle() = coordinator.toggleShuffle()
    fun disableVideoMode() = coordinator.disableVideoMode()
    fun setVideoQuality(quality: String) = coordinator.setVideoQuality(quality)
    fun play() = coordinator.play()
    fun pause() = coordinator.pause()
    fun stop() = coordinator.stop()
    fun togglePlayPause() = coordinator.togglePlayPause()
    fun playNext() = coordinator.playNext()
    fun playPrevious() = coordinator.playPrevious()
    fun seekTo(positionMs: Long) = coordinator.seekTo(positionMs)
    fun setPlaybackSpeed(speed: Float) = coordinator.setPlaybackSpeed(speed)
    fun toggleRepeat() = coordinator.toggleRepeat()
    fun fetchLyricsForCurrentSong(force: Boolean = false) = coordinator.fetchLyricsForCurrentSong(force)

    fun toggleLike(song: Song) {
        app.spasiba.nativeapp2.data.analytics.SessionBrainManager.recordLike(song)
        val currentlyLiked = likedSongIds.value.contains(song.id)
        scope.launch {
            repository.toggleLike(song)
            withContext(Dispatchers.Main) {
                val msg = if (!currentlyLiked) "❤️ Saved to Liked Songs" else "Removed from Liked Songs"
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
