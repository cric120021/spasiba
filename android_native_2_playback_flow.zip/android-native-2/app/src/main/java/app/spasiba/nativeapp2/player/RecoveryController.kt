package app.spasiba.nativeapp2.player

import app.spasiba.nativeapp2.data.api.StreamingResult
import app.spasiba.nativeapp2.data.model.Song
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Controller managing playback error recovery, retries, and network reconnection with generation safety.
 */
class RecoveryController(
    private val resolver: StreamResolver,
    private val scope: CoroutineScope,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val mainDispatcher: CoroutineDispatcher = Dispatchers.Main
) {
    val retryAttempts = LruMemoryCache<String, Int>(60)
    var recoveryJob: Job? = null

    fun cancelRecovery() {
        recoveryJob?.cancel()
        recoveryJob = null
    }

    fun resetRetries(songId: String) {
        retryAttempts.remove(songId)
    }

    fun clearAllRetries() {
        cancelRecovery()
        retryAttempts.clear()
    }

    fun attemptRecovery(
        currentSong: Song,
        currentPosMs: Long,
        generation: Long,
        resolvedVideoId: String?,
        isGenerationValid: (Long) -> Boolean,
        isSongActive: (String) -> Boolean,
        onSuccess: suspend (StreamingResult, Song, Long) -> Unit,
        onExhaustedOrFailed: () -> Unit
    ) {
        val currentRetries = retryAttempts[currentSong.id] ?: 0
        if (currentRetries >= 2) {
            retryAttempts.remove(currentSong.id)
            onExhaustedOrFailed()
            return
        }

        retryAttempts[currentSong.id] = currentRetries + 1
        cancelRecovery()

        recoveryJob = scope.launch(ioDispatcher) {
            try {
                val targetVideoId = resolvedVideoId ?: currentSong.id
                val freshResult = resolver.resolveAudioStream(targetVideoId, currentSong.title, currentSong.author)

                withContext(mainDispatcher) {
                    if (!isGenerationValid(generation) || !isSongActive(currentSong.id)) return@withContext

                    if (freshResult != null && freshResult.url.isNotBlank()) {
                        val updatedSong = currentSong.copy(streamUrl = freshResult.url)
                        onSuccess(freshResult, updatedSong, currentPosMs)
                    } else {
                        retryAttempts.remove(currentSong.id)
                        onExhaustedOrFailed()
                    }
                }
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                withContext(mainDispatcher) {
                    if (isGenerationValid(generation)) {
                        retryAttempts.remove(currentSong.id)
                        onExhaustedOrFailed()
                    }
                }
            } finally {
                recoveryJob = null
            }
        }
    }
}
