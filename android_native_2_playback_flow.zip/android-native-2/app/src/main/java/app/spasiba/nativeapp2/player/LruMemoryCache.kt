package app.spasiba.nativeapp2.player

/**
 * Thread-safe Bounded LRU Memory Cache with optional TTL expiration.
 * Evicts eldest accessed items when size exceeds [maxSize].
 */
class LruMemoryCache<K : Any, V : Any>(
    private val maxSize: Int,
    private val ttlMs: Long = 0L
) {
    private data class CacheEntry<V>(val value: V, val timestamp: Long)

    private val map = object : LinkedHashMap<K, CacheEntry<V>>(maxSize, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<K, CacheEntry<V>>?): Boolean {
            return size > maxSize
        }
    }

    @Synchronized
    operator fun get(key: K): V? {
        val entry = map[key] ?: return null
        if (ttlMs > 0L && (System.currentTimeMillis() - entry.timestamp) > ttlMs) {
            map.remove(key)
            return null
        }
        return entry.value
    }

    @Synchronized
    operator fun set(key: K, value: V) {
        map[key] = CacheEntry(value, System.currentTimeMillis())
    }

    @Synchronized
    fun put(key: K, value: V) {
        set(key, value)
    }

    @Synchronized
    fun remove(key: K): V? {
        return map.remove(key)?.value
    }

    @Synchronized
    fun clear() {
        map.clear()
    }

    @Synchronized
    fun size(): Int = map.size

    @Synchronized
    fun containsKey(key: K): Boolean = get(key) != null

    @Synchronized
    fun pruneExpired() {
        if (ttlMs <= 0L) return
        val now = System.currentTimeMillis()
        val iterator = map.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (now - entry.value.timestamp > ttlMs) {
                iterator.remove()
            }
        }
    }
}
